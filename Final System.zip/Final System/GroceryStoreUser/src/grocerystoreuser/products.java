/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package grocerystoreuser;


public class products {
    private int productId;
    private String categoryName; // Update: category name instead of ID
    private String name;
    private String code;
    private Double price;
    private Integer stock;
    private String status;

    public products(int productId, String categoryName, String name, String code, Double price,int stock, String status) {
        this.productId = productId;
        this.categoryName = categoryName; // Updated attribute
        this.name = name;
        this.code = code;
        this.price = price;
        this.stock = stock;
        this.status = status;
    }

    
    public products(Integer productId, String name, Double price, int stock){
        this.productId = productId;
        this.name = name;
        this.price = price;
        this.stock = stock;
    }
    // Getters for all attributes including categoryName
    public int getProductId() {
        return productId;
    }

    public String getCategoryName() {
        return categoryName;
    }

    public String getName() {
        return name;
    }

    public String getCode() {
        return code;
    }

    public Double getPrice() {
        return price;
    }
    
    public int getStock() {
        return stock;
    }

    public String getStatus() {
        return status;
    }
}

