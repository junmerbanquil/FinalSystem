/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package grocerystoreuser;

import java.sql.Statement;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.Connection;
import java.sql.SQLException;
import de.jensd.fx.glyphs.fontawesome.FontAwesomeIcon;
import javafx.geometry.Insets;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import javafx.collections.transformation.FilteredList;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.collections.transformation.SortedList;
import javafx.application.Platform;
import javafx.scene.layout.GridPane;

/**
 *
 * @author Wayt Turks
 */
public class dashboardController implements Initializable {

    
    
    @FXML
    private ComboBox<?> paymentMethod;
    
    @FXML
    private ComboBox<?> paymentMethod2;
    
    @FXML
    private ComboBox<address> cart_Address;
    
    @FXML
    private ComboBox<address> cart_address2;
    
    @FXML
    private GridPane menu_gridPane;
    
    @FXML
    private TableView<address> address_tableView;
    
    @FXML
    private TableView<cart> cartTable;
    
    @FXML
    private TableView<cart> cartTable2;
    
    @FXML
    private TableView<OrderDetails> order_details_table;

    @FXML
    private TableColumn<address, Integer> address_col_id;
    
    @FXML
    private TableColumn<address, Integer> order_col_productName;
     
    @FXML
    private TableColumn<address, Integer> order_col_quantity;
      
    @FXML
    private TableColumn<address, Integer> order_col_price;

    @FXML
    private TableColumn<address, Integer> address_col_userId;

    @FXML
    private TableColumn<address, String> address_col_street;

    @FXML
    private TableColumn<address, String> address_col_barangay;

    @FXML
    private TableColumn<address, String> address_col_municipality;

    @FXML
    private TableColumn<address, String> address_col_province;
    
    @FXML
    private TableColumn<cart, Integer> cart_cartID;

    @FXML
    private TableColumn<cart, Integer> cart_productName;

    @FXML
    private TableColumn<cart, String> cart_productQuantity;

    @FXML
    private TableColumn<cart, Integer> cart_productTotalPrice;
    
    @FXML
    private TableColumn<order, Integer> col_order_id;
    
    @FXML
    private TableColumn<order, Integer> col_order_total_quantity;
    
    @FXML
    private TableColumn<order, String> col_order_address;
    
    @FXML
    private TableColumn<order, Double> col_order_total;
    
    @FXML
    private TableColumn<order, Date> col_order_date;
    
    @FXML
    private TableView<order> order_table;
    
    @FXML
    private TableColumn<cart, Integer> cart_cartID2;

    @FXML
    private TableColumn<cart, Integer> cart_productName2;

    @FXML
    private TableColumn<cart, Integer> cart_productQuantity2;

    @FXML
    private TableColumn<cart, Double> cart_productPrice2;
    
    @FXML
    private TableColumn<cart, Integer> cart_productTotalPrice2;

    @FXML
    private TextField street;
    
    @FXML
    private TextField cart_totalQuantity2;

    @FXML
    private TextField address_id_display;

    @FXML
    private TextField barangay;

    @FXML
    private TextField municipality;
    
    @FXML
    private TextField cartID_display;
    
    @FXML
    private TextField orderID_display;
    
    @FXML
    private TextField cartID_display2;
    
    @FXML
    private TextField province;

    @FXML
    private TextField category_id;

    @FXML
    private TextField category_code;

    @FXML
    private TextField category_name;

    @FXML
    private Button category_addBtn;
    
    @FXML
    private Button cart_checkout;
    
    

    @FXML
    private FontAwesomeIcon close;

    @FXML
    private BarChart<?, ?> dashboard_NOrderChart;

    @FXML
    private Button dashboard_btn;

    @FXML
    private TextField userlogid;

    @FXML
    private BarChart<?, ?> dashboard_incomeChart;

    @FXML
    private AnchorPane dashboard_todaysIncome;

    @FXML
    private AnchorPane dashboard_totalIncome;

    @FXML
    private AnchorPane dashboard_totalProducts;

    @FXML
    private FontAwesomeIcon logout_btn;

    @FXML
    private FontAwesomeIcon minimize;

    @FXML
    private Button order_btn;

    @FXML
    private Button prod_addBtn;

    @FXML
    private Button prod_clearBtn;

    @FXML
    private Button category_clear;

    @FXML
    private Button products_btn;

    @FXML
    private Button address_btn;

    @FXML
    private Button cart_btn;

    @FXML
    private Button prod_deleteBtn;

    @FXML
    private Button category_deleteBtn;

    @FXML
    private Button category_btn;

    @FXML
    private AnchorPane products_form;

    @FXML
    private AnchorPane address_form;

    @FXML
    private AnchorPane cart_form;

    @FXML
    private AnchorPane order_form;

    @FXML
    private TextField prod_productCode;

    @FXML
    private TextField prod_productName;

    @FXML
    private TextField prod_productPrice;

    @FXML
    private ComboBox<?> prod_productStatus;

    @FXML
    private TextField prod_search;

    @FXML
    private Button prod_updateBtn;

    @FXML
    private AnchorPane main_form;

    @FXML
    private Label username;
    
    @FXML
    private Label cart_total2;
    
    
    @FXML
    private Label cart_total;
    
    @FXML
    private Label cart_totalQuantity;
    

    private Connection connect;
    private PreparedStatement prepare;
    private Statement statement;
    private ResultSet result;

    private ObservableList<products> cardListData = FXCollections.observableArrayList();

    public void switchForm(ActionEvent event) {
        if (event.getSource() == products_btn) {
            address_form.setVisible(false);
            products_form.setVisible(true);
            cart_form.setVisible(false);
            order_form.setVisible(false);

            products_btn.setStyle("-fx-background-color: #72e69a; -fx-text-fill: #fff; -fx-border-width: 0px;");
            address_btn.setStyle("-fx-background-color: transparent; -fx-border-width: 1px; -fx-text-fill: #000;");
            cart_btn.setStyle("-fx-background-color: transparent; -fx-border-width: 1px; -fx-text-fill: #000;");
            order_btn.setStyle("-fx-background-color: transparent; -fx-border-width: 1px; -fx-text-fill: #000;");
            menuDisplayCard();
            showCartData();
            
        } else if (event.getSource() == address_btn) {
            address_form.setVisible(true);
            products_form.setVisible(false);
            cart_form.setVisible(false);
            order_form.setVisible(false);

            products_btn.setStyle("-fx-background-color: transparent; -fx-border-width: 1px; -fx-text-fill: #000;");
            address_btn.setStyle("-fx-background-color: #72e69a; -fx-text-fill: #fff; -fx-border-width: 0px;");
            cart_btn.setStyle("-fx-background-color: transparent; -fx-border-width: 1px; -fx-text-fill: #000;");
            order_btn.setStyle("-fx-background-color: transparent; -fx-border-width: 1px; -fx-text-fill: #000;");

        } else if (event.getSource() == cart_btn) {
            address_form.setVisible(false);
            products_form.setVisible(false);
            cart_form.setVisible(true);
            order_form.setVisible(false);

            products_btn.setStyle("-fx-background-color: transparent; -fx-border-width: 1px; -fx-text-fill: #000;");
            address_btn.setStyle("-fx-background-color: transparent; -fx-border-width: 1px; -fx-text-fill: #000;");
            cart_btn.setStyle("-fx-background-color: #72e69a; -fx-text-fill: #fff; -fx-border-width: 0px;");
            order_btn.setStyle("-fx-background-color: transparent; -fx-border-width: 1px; -fx-text-fill: #000;");
            showCartData2();

        } else if (event.getSource() == order_btn) {
            address_form.setVisible(false);
            products_form.setVisible(false);
            cart_form.setVisible(false);
            order_form.setVisible(true);

            products_btn.setStyle("-fx-background-color: transparent; -fx-border-width: 1px; -fx-text-fill: #000;");
            address_btn.setStyle("-fx-background-color: transparent; -fx-border-width: 1px; -fx-text-fill: #000;");
            cart_btn.setStyle("-fx-background-color: transparent; -fx-border-width: 1px; -fx-text-fill: #000;");
            order_btn.setStyle("-fx-background-color: #72e69a; -fx-text-fill: #fff; -fx-border-width: 0px;");
            
            orderID_display.clear();
            allOrderShowData();
            allOrderDetailsShowData();
        } else if (event.getSource() == cart_checkout){
            address_form.setVisible(false);
            products_form.setVisible(true);
            cart_form.setVisible(false);
            order_form.setVisible(false);

            products_btn.setStyle("-fx-background-color: #72e69a; -fx-text-fill: #fff; -fx-border-width: 0px;");
            address_btn.setStyle("-fx-background-color: transparent; -fx-border-width: 1px; -fx-text-fill: #000;");
            cart_btn.setStyle("-fx-background-color: transparent; -fx-border-width: 1px; -fx-text-fill: #000;");
            order_btn.setStyle("-fx-background-color: transparent; -fx-border-width: 1px; -fx-text-fill: #000;");
            menuDisplayCard();
            showCartData();
        }
    }

    //DATA TABLE ADDRESS ########################################################
    //DATA TABLE ADDRESS ########################################################
    private ObservableList<address> getAddressListData(int userId) {
        ObservableList<address> listData = FXCollections.observableArrayList();

        String sql = "SELECT * FROM address WHERE user_id = ?"; // Added WHERE clause

        connect = (Connection) database.connect();

        try {
            prepare = connect.prepareStatement(sql);
            prepare.setInt(1, userId); // Set the user_id parameter in the prepared statement
            result = prepare.executeQuery();

            while (result.next()) {
                address addr = new address(
                        result.getInt("address_id"),
                        result.getInt("user_id"),
                        result.getString("street"),
                        result.getString("barangay"),
                        result.getString("municipality"),
                        result.getString("province")
                );
                listData.add(addr);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return listData;
    }

    public void showAddressData() {
        int userId = Integer.parseInt(userlogid.getText());
        address_col_id.setCellValueFactory(new PropertyValueFactory<>("addressId"));
        address_col_street.setCellValueFactory(new PropertyValueFactory<>("street"));
        address_col_barangay.setCellValueFactory(new PropertyValueFactory<>("barangay"));
        address_col_municipality.setCellValueFactory(new PropertyValueFactory<>("municipality"));
        address_col_province.setCellValueFactory(new PropertyValueFactory<>("province"));

        address_tableView.setItems(getAddressListData(userId));
    }
    //DATA TABLE ADDRESS ########################################################
    //DATA TABLE ADDRESS ########################################################

    
    //DATA TABLE CART ########################################################
    //DATA TABLE CART ########################################################
    private ObservableList<cart> getCartListData(int userId) {
        ObservableList<cart> listData = FXCollections.observableArrayList();

       String sql = "SELECT cart.*, product.product_name FROM cart INNER JOIN product ON cart.productID = product.productID WHERE cart.user_id = ?";

        connect = (Connection) database.connect();

        try {
            prepare = connect.prepareStatement(sql);
            prepare.setInt(1, userId); // Set the user_id parameter in the prepared statement
            result = prepare.executeQuery();

            while (result.next()) {
                cart carr = new cart(
                    result.getInt("cart_id"),
                    result.getInt("user_id"),
                    result.getInt("productID"),
                    result.getString("product_name"), // This will now work
                    result.getInt("quantity"),
                    result.getInt("price")
                );
                listData.add(carr);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return listData;
    }

    public void showCartData() {
        int userId = Integer.parseInt(userlogid.getText());
        cart_cartID.setCellValueFactory(new PropertyValueFactory<>("cartId"));
        cart_productName.setCellValueFactory(new PropertyValueFactory<>("productName"));
        cart_productQuantity.setCellValueFactory(new PropertyValueFactory<>("quantity"));
        cart_productTotalPrice.setCellValueFactory(new PropertyValueFactory<>("price"));

        ObservableList<cart> cartList = getCartListData(userId);
        cartTable.setItems(cartList);

        // Calculate the total price
        int totalPrice = cartList.stream().mapToInt(cart::getPrice).sum();
        int totalQuantity = cartList.stream().mapToInt(cart::getQuantity).sum();
        cart_total.setText(String.valueOf(totalPrice));
        cart_totalQuantity.setText(String.valueOf(totalQuantity));
    }

    //DATA TABLE CART ########################################################
    //DATA TABLE CART ########################################################
    
    
    
    //DATA TABLE CART 2 ################################################################################################################
    //DATA TABLE CART 2 ################################################################################################################
    private ObservableList<cart> getCartListData2(int userId) {
        ObservableList<cart> listData = FXCollections.observableArrayList();

        String sql = "SELECT cart.*, product.product_name, product.product_price " +
                     "FROM cart INNER JOIN product ON cart.productID = product.productID " +
                     "WHERE cart.user_id = ?";

        connect = (Connection) database.connect();

        try {
            prepare = connect.prepareStatement(sql);
            prepare.setInt(1, userId); // Set the user_id parameter in the prepared statement
            result = prepare.executeQuery();

            while (result.next()) {
                cart carr = new cart(
                    result.getInt("cart_id"),
                    result.getInt("user_id"),
                    result.getInt("productID"),
                    result.getString("product_name"),
                    result.getDouble("product_price"), // Correctly retrieving product_price
                    result.getInt("quantity"),
                    result.getInt("price")
                );
                listData.add(carr);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return listData;
    }

    public void showCartData2() {
        int userId = Integer.parseInt(userlogid.getText());
        cart_cartID2.setCellValueFactory(new PropertyValueFactory<>("cartId"));
        cart_productName2.setCellValueFactory(new PropertyValueFactory<>("productName"));
        cart_productPrice2.setCellValueFactory(new PropertyValueFactory<>("prodPrice")); // Adjusted to match the property name
        cart_productQuantity2.setCellValueFactory(new PropertyValueFactory<>("quantity"));
        cart_productTotalPrice2.setCellValueFactory(new PropertyValueFactory<>("price"));

        ObservableList<cart> cartList = getCartListData2(userId);
        cartTable2.setItems(cartList);

        // Calculate the total price
        double totalPrice = cartList.stream().mapToDouble(cart -> cart.getPrice()).sum();
        int totalQuantity = cartList.stream().mapToInt(cart -> cart.getQuantity()).sum();
        cart_total2.setText(String.valueOf(totalPrice));
        cart_totalQuantity2.setText(String.valueOf(totalQuantity));
    }

    //DATA TABLE CART 2 ################################################################################################################
    //DATA TABLE CART 2 ################################################################################################################
    
    
    
    //ORDERS DATA TABLE ########################################################
    //ORDERS DATA TABLE ########################################################
    private ObservableList<order> allOrderListData(){
        ObservableList<order> listData2 = FXCollections.observableArrayList();
        
        String sql = "SELECT o.orderID, o.total_quantity, o.address, o.grand_total, o.date " +
                     "FROM `order` o " +
                     "JOIN user u ON o.user_id = u.user_id";

        connect = (Connection) database.connect();

        try{
            prepare = connect.prepareStatement(sql);
            result = prepare.executeQuery();

            while(result.next()){
                
                int orderId = result.getInt("orderID");
                String grandTotalQuantity = result.getString("total_quantity");
                String address = result.getString("address");
                Double grandTotal = result.getDouble("grand_total");
                Date date = result.getDate("date");

                order order = new order(orderId, grandTotalQuantity, address, grandTotal, date);
                listData2.add(order);
            }
        } catch(Exception e){
            e.printStackTrace();
        }
        return listData2;
    }

    FilteredList<order> allOrderList;

    public void allOrderShowData(){
        allOrderList = new FilteredList<>(allOrderListData(), e -> true);
        SortedList<order> sortedList = new SortedList<>(allOrderList);
        
        col_order_id.setCellValueFactory(new PropertyValueFactory<>("orderID"));
        col_order_total_quantity.setCellValueFactory(new PropertyValueFactory<>("totalQuantity"));
        col_order_address.setCellValueFactory(new PropertyValueFactory<>("address"));
        col_order_total.setCellValueFactory(new PropertyValueFactory<>("grandTotal"));
        col_order_date.setCellValueFactory(new PropertyValueFactory<>("date"));

        order_table.setItems(sortedList);
        sortedList.comparatorProperty().bind(order_table.comparatorProperty());

    }
    
    
    //ORDERS DATA SELECT ########################################################
    //ORDERS DATA SELECT ########################################################
    public void allOrderSelect() {
        order selectedOrder = order_table.getSelectionModel().getSelectedItem();

        if (selectedOrder == null) {
            return; // No selection, do nothing
        }

        orderID_display.setText(String.valueOf(selectedOrder.getOrderID()));
        allOrderDetailsShowData();
    }

    //ORDERS DATA SELECT ########################################################
    //ORDERS DATA SELECT ########################################################
    
    
    //ORDER DETAILS TABLE VIEW ########################################################
    //ORDER DETAILS TABLE VIEW ########################################################
    private ObservableList<OrderDetails> allOrderDetailsListData(){
        ObservableList<OrderDetails> listData = FXCollections.observableArrayList();

        String sql = "SELECT orderdetails.orderID, product.product_name, orderdetails.quantity, orderdetails.total_price " +
                     "FROM orderdetails " +
                     "INNER JOIN product ON orderdetails.productID = product.productID " +
                     "WHERE orderdetails.orderID = ?";

        connect = (Connection) database.connect();

        try{
            prepare = connect.prepareStatement(sql);
            prepare.setString(1, orderID_display.getText());
            result = prepare.executeQuery();

            while(result.next()){

                int orderId = result.getInt("orderID");
                String productName = result.getString("product_name");
                String quantity = result.getString("quantity");
                Double totalPrice = result.getDouble("total_price");

                OrderDetails orderDetails = new OrderDetails(orderId, productName, quantity, totalPrice);
                listData.add(orderDetails);
            }
        } catch(Exception e){
            e.printStackTrace();
        }
        return listData;
    }

    FilteredList<OrderDetails> allOrderDetailsList;

    public void allOrderDetailsShowData(){
        allOrderDetailsList = new FilteredList<>(allOrderDetailsListData(), e -> true);
        SortedList<OrderDetails> sortedList = new SortedList<>(allOrderDetailsList);

        col_order_id.setCellValueFactory(new PropertyValueFactory<>("orderID"));
        order_col_productName.setCellValueFactory(new PropertyValueFactory<>("productName"));
        order_col_quantity.setCellValueFactory(new PropertyValueFactory<>("quantity"));
        order_col_price.setCellValueFactory(new PropertyValueFactory<>("totalPrice"));

        order_details_table.setItems(sortedList);
        sortedList.comparatorProperty().bind(order_details_table.comparatorProperty());
    }


    //ORDER DETAILS TABLE VIEW ########################################################
    //ORDER DETAILS TABLE VIEW ########################################################
    //ORDERS DATA TABLE ########################################################
    //ORDERS DATA TABLE ########################################################
    
    
    
    //ORDER CART #################################################################################################
    //ORDER CART #################################################################################################
public void proceedToOrder() {
    cardListData.clear();
    int userId = Integer.parseInt(userlogid.getText());
    String totalText = cart_total.getText();
    double totalPrice = Double.parseDouble(totalText);
    
    String totalQty = cart_totalQuantity.getText();
    int totalQuantity = Integer.parseInt(totalQty);

    if (cart_Address.getSelectionModel().isEmpty()) {
        Alert alert = new Alert(AlertType.ERROR);
        alert.setTitle("Error Message");
        alert.setHeaderText(null);
        alert.setContentText("Please select an address!");
        alert.showAndWait();
        return;
    }

    if (paymentMethod.getSelectionModel().isEmpty()) {
        Alert alert = new Alert(AlertType.ERROR);
        alert.setTitle("Error Message");
        alert.setHeaderText(null);
        alert.setContentText("Please select a payment method!");
        alert.showAndWait();
        return;
    }

    String status = "completed"; // Default status

    // Get the current system date
    SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
    Date date = new Date(System.currentTimeMillis());
    String systemDate = formatter.format(date);

    String sql = "INSERT INTO `order` (user_id, address, total_quantity, grand_total, date, status) VALUES (?, ?, ?, ?, ?, ?)";
    connect = (Connection) database.connect();

    try {
        Object selectedAddressObj = cart_Address.getSelectionModel().getSelectedItem();
        String selectedAddress = selectedAddressObj != null ? selectedAddressObj.toString() : "";

        Object selectedPaymentMethodObj = paymentMethod.getSelectionModel().getSelectedItem();
        String selectedPaymentMethod = selectedPaymentMethodObj != null ? selectedPaymentMethodObj.toString() : "";

        prepare = connect.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
        prepare.setInt(1, userId);
        prepare.setString(2, selectedAddress);
        prepare.setInt(3, totalQuantity);
        prepare.setDouble(4, totalPrice);
        prepare.setString(5, systemDate);
        prepare.setString(6, status);

        int affectedRows = prepare.executeUpdate();
        if (affectedRows == 0) {
            throw new SQLException("Creating order failed, no rows affected.");
        }

        try (ResultSet generatedKeys = prepare.getGeneratedKeys()) {
            if (generatedKeys.next()) {
                int orderID = generatedKeys.getInt(1);

                ObservableList<cart> cartItems = cartTable.getItems();
                String insertOrderDetailsQuery = "INSERT INTO orderdetails (orderID, productID, payment_method, quantity, total_price) VALUES (?, ?, ?, ?, ?)";
                prepare = connect.prepareStatement(insertOrderDetailsQuery);

                for (cart cartItem : cartItems) {
                    prepare.setInt(1, orderID);
                    prepare.setInt(2, cartItem.getProductId()); // Assuming you have a method to get product ID
                    prepare.setString(3, selectedPaymentMethod);
                    prepare.setInt(4, cartItem.getQuantity()); // Assuming getQuantity() returns the quantity
                    prepare.setDouble(5, cartItem.getPrice()); // Assuming getPrice() returns the total price

                    prepare.executeUpdate();
                }

                Alert alert = new Alert(AlertType.INFORMATION);
                alert.setTitle("Information Message");
                alert.setHeaderText(null);
                alert.setContentText("Order successfully placed!");
                alert.showAndWait();
                
                updateProductQuantitiesAndDelete();
                
                
            } else {
                throw new SQLException("Creating order failed, no ID obtained.");
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
        // Handle exceptions or show an error message if the insertion fails
    }
}
//DELETE ALL CART #################################################################################################
public void updateProductQuantitiesAndDelete() {
    try {
        String updateQuery = "UPDATE product SET product_stock = product_stock - ? WHERE productID = ?";
        prepare = connect.prepareStatement(updateQuery);
        
        ObservableList<cart> cartItems = cartTable.getItems();
        for (cart cartItem : cartItems) {
            int quantity = cartItem.getQuantity(); // Get the quantity from cartItem
            int productID = cartItem.getProductId(); // Get the product ID from cartItem
            
            prepare.setInt(1, quantity); // Set the quantity to be deducted
            prepare.setInt(2, productID); // Set the product ID
            prepare.executeUpdate();
        }
        
        String deleteQuery = "DELETE FROM cart";
        prepare = connect.prepareStatement(deleteQuery);
        prepare.executeUpdate();
        
        // Refresh the cart table or perform any other necessary actions
        showCartData();
        menuDisplayCard();
    } catch (Exception e) {
        e.printStackTrace();
        // Handle exceptions or show an error message if the operation fails
    }
}


    //ORDER CART #################################################################################################
    //ORDER CART #################################################################################################
    
    
    
    
    
    private double x = 0;
    private double y = 0;

    public void logout() {
        try {
            Alert alert = new Alert(AlertType.INFORMATION);
            alert.setTitle("Information Message");
            alert.setHeaderText(null);
            alert.setContentText("Are you sure you want to logout?");
            Optional<ButtonType> option = alert.showAndWait();

            if (option.isPresent() && option.get().equals(ButtonType.OK)) {

                logout_btn.getScene().getWindow().hide();

                Parent root = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
                Stage stage = new Stage();
                Scene scene = new Scene(root);

                stage.initStyle(StageStyle.TRANSPARENT);

                root.setOnMousePressed((MouseEvent event) -> {
                    x = event.getSceneX();
                    y = event.getSceneY();
                });

                root.setOnMouseDragged((MouseEvent event) -> {
                    stage.setX(event.getScreenX() - x);
                    stage.setY(event.getScreenY() - y);

                    stage.setOpacity(.8f);
                });

                root.setOnMouseReleased((MouseEvent event) -> {
                    stage.setOpacity(1);
                });

                stage.setScene(scene);
                stage.show();
            }

        } catch (IOException e) {
        }
    }

    public void displayUsername() {
        String user = data.username;
        user = user.substring(0, 1).toUpperCase() + user.substring(1);
        username.setText(user);
        retrieveUserId();
    }

    //RETRIEVE USER DATA ########################################################
    //RETRIEVE USER DATA ########################################################
    //ALL PRODUCTS ########################################################
    //ALL PRODUCTS ########################################################
    public ObservableList<products> menuGetData() {
        String sql = "SELECT * FROM product WHERE product_stock != 0";

        ObservableList<products> listData = FXCollections.observableArrayList();
        connect = database.connect();

        try {
            prepare = connect.prepareStatement(sql);
            result = prepare.executeQuery();

            products prod;

            while (result.next()) {
               prod = new products(result.getInt("productID"), result.getString("product_name"), result.getDouble("product_price"), result.getInt("product_stock"));

                        listData.add(prod);
            }
            }catch (Exception e) {
            e.printStackTrace();
        }

        return listData;
    }

    public void menuDisplayCard() {
        cardListData.clear();
        cardListData.addAll(menuGetData());

        int row = 0;
        int column = 0;
        
        menu_gridPane.getChildren().clear();
        menu_gridPane.getRowConstraints().clear();
        menu_gridPane.getColumnConstraints().clear();
        
        for (int q = 0; q < cardListData.size(); q++) {
            
        try {
            FXMLLoader load = new FXMLLoader();
            load.setLocation(getClass().getResource("cardProduct.fxml"));
            AnchorPane pane = load.load();
            cardProductController cardC = load.getController();

            // Create a new products instance and set its details
            products productData = cardListData.get(q);
            cardC.setData(productData);

            // Pass the product data to setQuantity method
            cardC.setQuantity(productData);

            if (column == 3) {
                column = 0;
                row += 1;
            }

            menu_gridPane.add(pane, column++, row);
            GridPane.setMargin(pane, new Insets(8));
        } catch (Exception e) {
            e.printStackTrace();
        }

        }
    }
    //ALL PRODUCTS ########################################################
    //ALL PRODUCTS ########################################################
    
    //RETRIEVE USER DATA ########################################################
    //RETRIEVE USER DATA ########################################################
    public void retrieveUserId() {
        String usernames = data.username;

        String sql = "SELECT user_id FROM user WHERE username = ?";

        connect = (Connection) database.connect();

        try {
            prepare = connect.prepareStatement(sql);
            prepare.setString(1, usernames);
            result = prepare.executeQuery();

            if (result.next()) {
                int userId = result.getInt("user_id");
                userlogid.setText(String.valueOf(userId));
                getAddressListData(userId);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    //RETRIEVE USER DATA ########################################################
    //RETRIEVE USER DATA ########################################################
    
    
    
    //ADD ADDRESS TO COMBO BOX ########################################################
    //ADD ADDRESS TO COMBO BOX ########################################################
    private ObservableList<address> getAllCategories() {
        ObservableList<address> catList = FXCollections.observableArrayList();

        String sql = "SELECT address_id, user_id, street, barangay, municipality, province FROM address WHERE user_id = ?";
        connect = database.connect();
        try {
            prepare = connect.prepareStatement(sql);
            prepare.setInt(1, Integer.parseInt(userlogid.getText())); // Assuming userlogid is a TextField
            result = prepare.executeQuery();

            while (result.next()) {
                int addressId = result.getInt("address_id");
                int userId = result.getInt("user_id");
                String streets = result.getString("street");
                String barangays = result.getString("barangay");
                String municipalitys = result.getString("municipality");
                String provinces = result.getString("province");

                address cat = new address(addressId, userId, streets, barangays, municipalitys, provinces);
                catList.add(cat);
            }

            // Close resources after usage
            result.close();
            prepare.close();
            connect.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return catList;
    }

    private ObservableList<address> allAddress;

    public void populateAddressComboBox() {
        allAddress = getAllCategories();
        cart_Address.setItems(allAddress); // Set items to the ComboBox
    }

    //ADD CATEGORY TO COMBO BOX ########################################################
    //ADD ADDRESS TO COMBO BOX ########################################################
    
    
    
    //ADD ADDRESS ########################################################
    //ADD ADDRESS ######################################################## 
    public void addAddress() {
        String sqlCheckAddress = "SELECT * FROM address WHERE user_id = ? AND street = ? AND barangay = ? AND municipality = ? AND province = ?";
        String sqlInsert = "INSERT INTO address (user_id, street, barangay, municipality, province) VALUES (?,?,?,?,?)";
        connect = database.connect();

        try {
            if (street.getText().isEmpty() || barangay.getText().isEmpty() || municipality.getText().isEmpty() || province.getText().isEmpty()) {
                Alert alert = new Alert(AlertType.ERROR);
                alert.setTitle("Error Message");
                alert.setHeaderText(null);
                alert.setContentText("Please fill all fields!");
                alert.showAndWait();
                return; // Exit method if any field is empty
            }

            // Check if address already exists for the specific user
            PreparedStatement checkAddressStatement = connect.prepareStatement(sqlCheckAddress);
            int userId = Integer.parseInt(userlogid.getText()); // Get the user_id from the TextField
            checkAddressStatement.setInt(1, userId);
            checkAddressStatement.setString(2, street.getText());
            checkAddressStatement.setString(3, barangay.getText());
            checkAddressStatement.setString(4, municipality.getText());
            checkAddressStatement.setString(5, province.getText());
            ResultSet addressResult = checkAddressStatement.executeQuery();

            if (addressResult.next()) {
                Alert alert = new Alert(AlertType.ERROR);
                alert.setTitle("Error Message");
                alert.setHeaderText(null);
                alert.setContentText("Address already exists for this user!");
                alert.showAndWait();
                return; // Exit method if the address already exists for the specific user
            }

            // If address doesn't exist for the specific user and all fields are filled, proceed with insertion
            PreparedStatement insertStatement = connect.prepareStatement(sqlInsert);

            insertStatement.setInt(1, userId);
            insertStatement.setString(2, street.getText());
            insertStatement.setString(3, barangay.getText());
            insertStatement.setString(4, municipality.getText());
            insertStatement.setString(5, province.getText());

            insertStatement.executeUpdate();

            Alert alert = new Alert(AlertType.INFORMATION);
            alert.setTitle("Information Message");
            alert.setHeaderText(null);
            alert.setContentText("Successfully Added!");
            alert.showAndWait();

            showAddressData();
            allAddressClear();
        } catch (SQLException | NumberFormatException e) {
            e.printStackTrace();
        }
    }

    //ADD ADDRESS ########################################################
    //ADD ADDRESS ########################################################  
    //SELECT ADDRESS ########################################################
    //SELECT ADDRESS ########################################################  
    public void allAddressSelect() {

        address addData = address_tableView.getSelectionModel().getSelectedItem();
        int num = address_tableView.getSelectionModel().getSelectedIndex();

        if ((num - 1) < -1) {
            return;
        }
        address_id_display.setText(String.valueOf(addData.getAddressId()));
        street.setText(addData.getStreet());
        barangay.setText(addData.getBarangay());
        municipality.setText(addData.getMunicipality());
        province.setText(addData.getProvince());
    }
    //SELECT ADDRESS ########################################################
    //SELECT ADDRESS ########################################################  

    //UPDATE ADDRESS ########################################################
    //UPDATE ADDRESS ########################################################  
    public void updateAddress() {
        String sql = "UPDATE address SET street = ?, barangay = ?, municipality = ?, province = ? WHERE address_id = ?";

        String checkSql = "SELECT * FROM address WHERE user_id = ? AND street = ? AND barangay = ? AND municipality = ? AND province = ?";

        try {

            PreparedStatement checkStmt = connect.prepareStatement(checkSql);
            PreparedStatement stmt = connect.prepareStatement(sql);
            Alert alert;

            checkStmt.setInt(1, Integer.parseInt(userlogid.getText()));
            checkStmt.setString(2, street.getText());
            checkStmt.setString(3, barangay.getText());
            checkStmt.setString(4, municipality.getText());
            checkStmt.setString(5, province.getText());

            ResultSet rs = checkStmt.executeQuery();

            if (!street.getText().equals("") && !barangay.getText().equals("")
                    && !municipality.getText().equals("") && !province.getText().equals("")) {

                if (rs.next()) {
                    alert = new Alert(AlertType.INFORMATION);
                    alert.setContentText("Address already exists");
                    alert.show();

                } else {

                    stmt.setString(1, street.getText());
                    stmt.setString(2, barangay.getText());
                    stmt.setString(3, municipality.getText());
                    stmt.setString(4, province.getText());
                    stmt.setInt(5, Integer.parseInt(address_id_display.getText()));

                    int count = stmt.executeUpdate();

                    if (count > 0) {
                        alert = new Alert(AlertType.INFORMATION);
                        alert.setContentText("Address updated");
                    } else {
                        alert = new Alert(AlertType.INFORMATION);
                        alert.setContentText("No changes made");
                    }
                    alert.show();
                }

            } else {
                // Show error for empty fields
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

    }
    //UPDATE ADDRESS ########################################################
    //UPDATE ADDRESS ########################################################  

    //DELETE ADDRESS ########################################################
    //DELETE ADDRESS ########################################################  
    public void allAddressDelete() {
        String sql = "DELETE FROM address WHERE address_id = '" + address_id_display.getText() + "'";

        connect = database.connect();

        try {
            Alert alert;

            if (address_id_display.getText().isEmpty()) {
                alert = new Alert(AlertType.ERROR);
                alert.setTitle("Error Message");
                alert.setHeaderText(null);
                alert.setContentText("Please select Address to Delete");
                alert.showAndWait();
            } else {

                alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Message");
                alert.setHeaderText(null);
                alert.setContentText("Are you sure you want to Delete Address ID: " + address_id_display.getText() + "?");
                Optional<ButtonType> option = alert.showAndWait();

                if (option.get().equals(ButtonType.OK)) {

                    alert = new Alert(AlertType.INFORMATION);
                    alert.setTitle("Information Message");
                    alert.setHeaderText(null);
                    alert.setContentText("Successfully Deleted!");
                    alert.showAndWait();

                    statement = connect.createStatement();
                    statement.executeUpdate(sql);

                    //show data on table
                    showAddressData();
                    //clear text field
                    allAddressClear();

                } else {

                    alert = new Alert(AlertType.INFORMATION);
                    alert.setTitle("Information Message");
                    alert.setHeaderText(null);
                    alert.setContentText("Cancelled");
                    alert.showAndWait();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    //DELETE ADDRESS ########################################################
    //DELETE ADDRESS ########################################################  

    // CLEAR ADDRESS TEXT FIELDS ############################################################
    // CLEAR ADDRESS TEXT FIELDS ############################################################
    public void allAddressClear() {
        address_id_display.setText("");
        street.setText("");
        barangay.setText("");
        municipality.setText("");
        province.setText("");
    }
    // CLEAR ADDRESS TEXT FIELDS ############################################################
    // CLEAR ADDRESS TEXT FIELDS ############################################################

    // PAYMENT METHOD ############################################################
    // PAYMENT METHOD ############################################################
    private final String[] PaymentM = {"Cash On Delivery", "Credit Card", "GCash", "PayMaya"};
    public void PaymentMethod(){
        List<String> listPM = new ArrayList<>();

        for(String data: PaymentM){
                listPM.add(data);
        }

        ObservableList listData = FXCollections.observableArrayList(listPM);
        paymentMethod.setItems(listData);
    }
    // PAYMENT METHOD ############################################################
    // PAYMENT METHOD ############################################################
    
    
    // REMOVE CART ############################################################
    // REMOVE CART ############################################################
    public void allCartDelete() {
        String sql = "DELETE FROM cart WHERE cart_id = '" + cartID_display.getText() + "'";

        connect = database.connect();

        try {
            Alert alert;

            if (cartID_display.getText().isEmpty()) {
                alert = new Alert(AlertType.ERROR);
                alert.setTitle("Error Message");
                alert.setHeaderText(null);
                alert.setContentText("Please select product to remove");
                alert.showAndWait();
            } else {

                alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Message");
                alert.setHeaderText(null);
                alert.setContentText("Are you sure you want to remove : " + cart_productName.getText() + "?");
                Optional<ButtonType> option = alert.showAndWait();

                if (option.get().equals(ButtonType.OK)) {

                    alert = new Alert(AlertType.INFORMATION);
                    alert.setTitle("Information Message");
                    alert.setHeaderText(null);
                    alert.setContentText("Successfully Removed!");
                    alert.showAndWait();
                    
                    
                    statement = connect.createStatement();
                    statement.executeUpdate(sql);
                    //show data on table
                    showAddressData();
                    showCartData();
                    allAddressClear();

                } else {

                    alert = new Alert(AlertType.INFORMATION);
                    alert.setTitle("Information Message");
                    alert.setHeaderText(null);
                    alert.setContentText("Cancelled");
                    alert.showAndWait();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void allCartDelete2() {
        String sql = "DELETE FROM cart WHERE cart_id = '" + cartID_display2.getText() + "'";

        connect = database.connect();

        try {
            Alert alert;

            if (cartID_display2.getText().isEmpty()) {
                alert = new Alert(AlertType.ERROR);
                alert.setTitle("Error Message");
                alert.setHeaderText(null);
                alert.setContentText("Please select product to remove");
                alert.showAndWait();
            } else {

                alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Message");
                alert.setHeaderText(null);
                alert.setContentText("Are you sure?");
                Optional<ButtonType> option = alert.showAndWait();

                if (option.get().equals(ButtonType.OK)) {

                    alert = new Alert(AlertType.INFORMATION);
                    alert.setTitle("Information Message");
                    alert.setHeaderText(null);
                    alert.setContentText("Successfully Removed!");
                    alert.showAndWait();
                    
                    
                    statement = connect.createStatement();
                    statement.executeUpdate(sql);
                    //show data on table
                    showAddressData();
                    showCartData2();
                    allAddressClear();
                    cartID_display2.setText("");

                } else {

                    alert = new Alert(AlertType.INFORMATION);
                    alert.setTitle("Information Message");
                    alert.setHeaderText(null);
                    alert.setContentText("Cancelled");
                    alert.showAndWait();
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    // REMOVE CART ############################################################
    // REMOVE CART ############################################################
    
    
    // SELECT CART ############################################################
    // SELECT CART ############################################################
    public void AllCartSelect() {

        cart cartData = cartTable.getSelectionModel().getSelectedItem();
        int num = cartTable.getSelectionModel().getSelectedIndex();

        if ((num - 1) < -1) {
            return;
        }
        cartID_display.setText(String.valueOf(cartData.getCartId()));

    }
    public void AllCartSelect2() {

        cart cartData = cartTable2.getSelectionModel().getSelectedItem();
        int num = cartTable2.getSelectionModel().getSelectedIndex();

        if ((num - 1) < -1) {
            return;
        }
        cartID_display2.setText(String.valueOf(cartData.getCartId()));

    }
    // SELECT CART ############################################################
    // SELECT CART ############################################################
    
    public void close() {
        System.exit(0);
    }

    public void minimize() {
        Stage stage = (Stage) main_form.getScene().getWindow();
        stage.setIconified(true);
    }

    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // load data, initialize UI components, etc
        displayUsername();
        showAddressData();
        showCartData();
        showCartData2();
        menuDisplayCard();
        PaymentMethod();
        allOrderShowData();
        populateAddressComboBox();

    }

}
