/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package grocerystoreuser;


public class cart {
    private int cartId;
    private int userId;
    private int productId;
    private String productName;
    private int quantity;
    private int price;
    private Double prodPrice;

    public cart(int cartId, int userId, int productId, String productName, int quantity, int price) {
        this.cartId = cartId;
        this.userId = userId;
        this.productId = productId;
        this.productName = productName; // And this line
        this.quantity = quantity;
        this.price = price;
    }

    public cart(int cartId, int userId, int productId, String productName, Double prodPrice, int quantity, int price) {
        this.cartId = cartId;
        this.userId = userId;
        this.productId = productId;
        this.productName = productName; // And this line
        this.prodPrice = prodPrice;
        this.quantity = quantity;
        this.price = price;
    }

    // Getters for all attributes including categoryName
    public int getCartId() {
        return cartId;
    }

    public int getUserId() {
        return userId;
    }

    public int getProductId() {
        return productId;
    }
    
    public String getProductName() { 
        return productName;
    }
    
    public Double getProdPrice() {
        return prodPrice;
    }

    public int getQuantity() {
        return quantity;
    }

    public int getPrice() {
        return price;
    }
}

