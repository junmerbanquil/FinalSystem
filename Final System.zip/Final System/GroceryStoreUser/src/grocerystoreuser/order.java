/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package grocerystoreuser;

import java.util.Date;


public class order {
    private int orderID;
    private String totalQuantity;
    private String address;
    private Date date;
    private Double grandTotal;

    public order(int orderID, String totalQuantity, String address,Double grandTotal, Date date) {
        this.orderID = orderID;
        this.totalQuantity = totalQuantity;
        this.address = address;
        this.grandTotal = grandTotal;
        this.date = date;
    }

    public int getOrderID() {
        return orderID;
    }

    public String getTotalQuantity() {
        return totalQuantity;
    }

    public String getAddress() {
        return address;
    }
    
    public Double getGrandTotal() {
        return grandTotal;
    }

    public Date getDate() {
        return date;
    }
}
