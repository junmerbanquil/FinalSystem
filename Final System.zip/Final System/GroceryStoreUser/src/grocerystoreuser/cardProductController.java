/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package grocerystoreuser;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;
import java.sql.SQLException;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;


/**
 *
 * @author Wayt Turks
 */
public class cardProductController implements Initializable{

     private CartUpdateListener cartUpdateListener;
    
     public void setCartUpdateListener(CartUpdateListener listener) {
        this.cartUpdateListener = listener;
    }
    @FXML
    private AnchorPane card_form;

    @FXML
    private Label username;
    
    @FXML
    private Button prod_addBtn;

    @FXML
    private ImageView prod_image;

    @FXML
    private Label prod_name;

    @FXML
    private Label prod_price;

    @FXML
    private Spinner<Integer> prod_spinner;
    
    private Connection connect;
    private PreparedStatement prepare;
    private ResultSet result;
    
    private products prodData;
    
    private SpinnerValueFactory<Integer> spin;
    
    public void setData(products prodData) {
        this.prodData = prodData;
        prod_name.setText(prodData.getName());
        prod_price.setText("₱" + String.valueOf(prodData.getPrice()));
        String user = data.username;
        user = user.substring(0, 1).toUpperCase() + user.substring(1);
        username.setText(user);
    }
    
    private int qty;
    public void setQuantity(products prodData) {
        this.prodData = prodData; // Ensure prodData is set

        if (prodData != null) {
            int maxStock = prodData.getStock(); // Get the stock count from the product
            spin = new SpinnerValueFactory.IntegerSpinnerValueFactory(1, maxStock, 0);
            prod_spinner.setValueFactory(spin);
        }
    }
    
public void addToCart() {
    
    String sqlCheckCart = "SELECT * FROM cart WHERE user_id = ? AND productID = ?";
    String sqlInsert = "INSERT INTO cart (user_id, productID, quantity, price) VALUES (?, ?, ?, ?)";
    connect = database.connect();

    try {
        int productId = prodData.getProductId();
        int selectedQuantity = prod_spinner.getValue();
        double price = prodData.getPrice(); // Assuming prodData has the price

        // Get the user_id based on the username
        String getUserIdQuery = "SELECT user_id FROM user WHERE username = ?";
        PreparedStatement getUserIdStatement = connect.prepareStatement(getUserIdQuery);
        getUserIdStatement.setString(1, username.getText());
        ResultSet userResult = getUserIdStatement.executeQuery();

        int userID = 0; // Default user_id value

        if (userResult.next()) {
            userID = userResult.getInt("user_id");
        }

        int maxStock = prodData.getStock(); // Assuming prodData has the stock count

        // Check if the product already exists in the user's cart
        PreparedStatement checkStatement = connect.prepareStatement(sqlCheckCart);
        checkStatement.setInt(1, userID);
        checkStatement.setInt(2, productId);
        ResultSet resultSet = checkStatement.executeQuery();

        if (resultSet.next()) {
            // Product already exists in the cart for this user
            int existingQuantity = resultSet.getInt("quantity");
            int totalQuantity = existingQuantity + selectedQuantity;

            if (totalQuantity > maxStock) {
                Alert alert = new Alert(AlertType.INFORMATION);
                alert.setTitle("Information Message");
                alert.setHeaderText(null);
                alert.setContentText("You have already added the maximum stock of this product!");
                alert.showAndWait();
            } else {
                PreparedStatement updateStatement = connect.prepareStatement("UPDATE cart SET quantity = ?, price = ? WHERE user_id = ? AND productID = ?");
                double newPrice = price * totalQuantity; // Calculate the new total price

                updateStatement.setInt(1, totalQuantity);
                updateStatement.setDouble(2, newPrice);
                updateStatement.setInt(3, userID);
                updateStatement.setInt(4, productId);
                updateStatement.executeUpdate();

                Alert alert = new Alert(AlertType.INFORMATION);
                alert.setTitle("Information Message");
                alert.setHeaderText(null);
                alert.setContentText("Successfully Added!");
                alert.showAndWait();
                if (cartUpdateListener != null) {
                    cartUpdateListener.onCartUpdated();
                }
            }
        } else {
            if (selectedQuantity > maxStock) {
                Alert alert = new Alert(AlertType.INFORMATION);
                alert.setTitle("Information Message");
                alert.setHeaderText(null);
                alert.setContentText("You are trying to add more than the available stock of this product!");
                alert.showAndWait();
            } else {
                // Insert a new entry into the cart
                PreparedStatement insertStatement = connect.prepareStatement(sqlInsert);
                insertStatement.setInt(1, userID);
                insertStatement.setInt(2, productId);
                insertStatement.setInt(3, selectedQuantity);
                insertStatement.setDouble(4, price * selectedQuantity); // Calculate total price

                insertStatement.executeUpdate();

                Alert alert = new Alert(AlertType.INFORMATION);
                alert.setTitle("Information Message");
                alert.setHeaderText(null);
                alert.setContentText("Successfully Added!");
                alert.showAndWait();
                if (cartUpdateListener != null) {
                    cartUpdateListener.onCartUpdated();
                }
            }
        }
    } catch (SQLException | NumberFormatException e) {
        e.printStackTrace();
    }
}



    
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        setQuantity(prodData);
    }
}
