/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package grocerystoreuser;


public class user {
    int userid;
    private String fname; 
    private String mname;
    private String lname;
    private String sex;
    private String bdate;
    private String email;
    private String username;

    public user(int userid, String fname, String mname, String lname, String sex, String bdate, String email, String username) {
        this.userid = userid; 
        this.fname = fname;
        this.mname = mname;
        this.lname = lname;
        this.sex = sex;
        this.bdate = bdate;
        this.email = email;
        this.username = username;
    }

    // Getters for all attributes including categoryName
    public int getUserId() {
        return userid;
    }
    public String getFname() {
        return fname;
    }
    public String getMname() {
        return mname;
    }
    public String getLname() {
        return lname;
    }
    public String getSex() {
        return sex;
    }
    public String getBdate() {
        return bdate;
    }
    public String getEmail() {
        return email;
    }
    public String getUsername() {
        return username;
    }
}