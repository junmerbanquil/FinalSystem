/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package grocerystoreuser;


public class address {
    private int addressId;
    private int userid;
    private String street; // Update: category name instead of ID
    private String barangay;
    private String municipality;
    private String province;

    public address(int addressId,int userid, String street, String barangay, String municipality, String province) {
        this.addressId = addressId;
        this.userid = userid; 
        this.street = street;
        this.barangay = barangay;
        this.municipality = municipality;
        this.province = province;
    }

    @Override
    public String toString() {
        return street + ", " + barangay + ", " + municipality + ", " + province;
    }
    // Getters for all attributes including categoryName
    public int getAddressId() {
        return addressId;
    }

    public int getUserId() {
        return userid;
    }

    public String getStreet() {
        return street;
    }

    public String getBarangay() {
        return barangay;
    }

    public String getMunicipality() {
        return municipality;
    }

    public String getProvince() {
        return province;
    }
}

