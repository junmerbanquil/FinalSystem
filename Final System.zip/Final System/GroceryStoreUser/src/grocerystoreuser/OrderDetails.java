/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package grocerystoreuser;


public class OrderDetails {
    private int orderDetailsId;
    private int orderId;
    private String productName;
    private String payment;
    private String quantity;
    private Double totalPrice;
    private int productId; 
    private Double totalSales; 


    public OrderDetails(int orderId, String productName, String quantity, Double totalPrice) {
        this.orderId = orderId;
        this.productName = productName;
        this.quantity = quantity;
        this.totalPrice = totalPrice;
    }
   
    public OrderDetails(int productId, String productName, Double totalSales) {
        this.productId = productId;
        this.productName = productName;
        this.totalSales = totalSales;
    }
    
    public int getOrderDetailsId() {
        return orderDetailsId;
    }

    public int getOrderId() {
        return orderId;
    }

    public String getProductName() {
        return productName;
    }

    public String getPayment() {
        return payment;
    }

    public String getQuantity() {
        return quantity;
    }

    public Double getTotalPrice() {
        return totalPrice;
    }
    
    public int getProductId() {
        return productId;
    }

    public Double getTotalSales() {
        return totalSales;
    }
}

