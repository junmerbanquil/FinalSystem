-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 08, 2024 at 06:21 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `grocerystore`
--

-- --------------------------------------------------------

--
-- Table structure for table `address`
--

CREATE TABLE `address` (
  `address_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `street` varchar(100) NOT NULL,
  `barangay` varchar(100) NOT NULL,
  `municipality` varchar(100) NOT NULL,
  `province` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `address`
--

INSERT INTO `address` (`address_id`, `user_id`, `street`, `barangay`, `municipality`, `province`) VALUES
(1, 4, 'Prk 10', 'San Vicente', 'Banaybanay', 'Davao Oriental'),
(3, 5, 'Prk 6-A', 'Poblacion', 'Banaybanay', 'Davao Oriental'),
(4, 5, 'Prk 9', 'San Vicente', 'Banaybanay', 'Davao Oriental'),
(5, 7, 'Purok 9', 'San Vicente', 'Banaybanay', 'Davao Oriental');

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `mname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `email`, `fname`, `mname`, `lname`, `username`, `password`) VALUES
(31, 'junmer@gmail.com', 'Junmer', '', 'Banquil', 'junmer', '80cf952476e68466a6ec1a9b340ae702ff5933a739cea60d049f5f7109bf1f4a'),
(32, 'kristine@gmail.com', 'Junmer', '', 'Banquil', 'lang', '414bcda764694ffe8a34d346a6560e2f87d926782a1244aeb14673b104c74eea'),
(33, 'junmerbanquil@gmail.com', 'Junmer', '', 'Banquil', 'Banquil', '80cf952476e68466a6ec1a9b340ae702ff5933a739cea60d049f5f7109bf1f4a');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `cart_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `productID` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `categoryID` int(11) NOT NULL,
  `category_name` varchar(100) NOT NULL,
  `category_code` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`categoryID`, `category_name`, `category_code`) VALUES
(5, 'Canned Goods', 'C001'),
(6, 'Frozen Foods', 'F001'),
(8, 'Dry Goods', 'D001'),
(9, 'Household Goods', 'H001');

-- --------------------------------------------------------

--
-- Table structure for table `order`
--

CREATE TABLE `order` (
  `orderID` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `address` varchar(100) NOT NULL,
  `total_quantity` varchar(100) NOT NULL,
  `grand_total` double NOT NULL,
  `date` date NOT NULL,
  `status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `order`
--

INSERT INTO `order` (`orderID`, `user_id`, `address`, `total_quantity`, `grand_total`, `date`, `status`) VALUES
(26, 4, 'Prk 10, San Vicente, Banaybanay, Davao Oriental', '6', 107, '2023-12-27', 'completed'),
(27, 4, 'Prk 10, San Vicente, Banaybanay, Davao Oriental', '2', 22, '2023-12-27', 'completed'),
(28, 7, 'Purok 9, San Vicente, Banaybanay, Davao Oriental', '3', 39, '2023-12-28', 'completed'),
(29, 7, 'Purok 9, San Vicente, Banaybanay, Davao Oriental', '14', 222, '2023-12-29', 'completed'),
(30, 7, 'Purok 9, San Vicente, Banaybanay, Davao Oriental', '1', 12, '2024-01-05', 'completed'),
(31, 7, 'Purok 9, San Vicente, Banaybanay, Davao Oriental', '1', 12, '2024-01-05', 'completed'),
(32, 7, 'Purok 9, San Vicente, Banaybanay, Davao Oriental', '5', 72, '2024-01-05', 'completed'),
(33, 7, 'Purok 9, San Vicente, Banaybanay, Davao Oriental', '1', 15, '2024-01-08', 'completed');

-- --------------------------------------------------------

--
-- Table structure for table `orderdetails`
--

CREATE TABLE `orderdetails` (
  `orderDetailsID` int(11) NOT NULL,
  `orderID` int(11) NOT NULL,
  `productID` int(11) NOT NULL,
  `payment_method` varchar(100) NOT NULL,
  `quantity` int(11) NOT NULL,
  `total_price` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orderdetails`
--

INSERT INTO `orderdetails` (`orderDetailsID`, `orderID`, `productID`, `payment_method`, `quantity`, `total_price`) VALUES
(36, 26, 28, 'Cash On Delivery', 1, 12),
(37, 26, 30, 'Cash On Delivery', 1, 15),
(38, 26, 35, 'Cash On Delivery', 4, 80),
(39, 27, 38, 'Cash On Delivery', 1, 10),
(40, 27, 39, 'Cash On Delivery', 1, 12),
(41, 28, 28, 'Cash On Delivery', 2, 24),
(42, 28, 30, 'Cash On Delivery', 1, 15),
(43, 29, 36, 'Cash On Delivery', 3, 51),
(44, 29, 37, 'Cash On Delivery', 3, 75),
(45, 29, 39, 'Cash On Delivery', 8, 96),
(46, 30, 28, 'Cash On Delivery', 1, 12),
(47, 31, 28, 'Cash On Delivery', 1, 12),
(48, 32, 28, 'Cash On Delivery', 1, 12),
(49, 32, 30, 'Cash On Delivery', 4, 60),
(50, 33, 30, 'Cash On Delivery', 1, 15);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `productID` int(11) NOT NULL,
  `categoryID` int(11) NOT NULL,
  `product_name` varchar(100) NOT NULL,
  `product_code` varchar(100) NOT NULL,
  `product_price` double NOT NULL,
  `product_stock` int(100) NOT NULL,
  `product_status` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`productID`, `categoryID`, `product_name`, `product_code`, `product_price`, `product_stock`, `product_status`) VALUES
(30, 5, 'Coke', 'C001', 15, 93, 'Available'),
(31, 5, 'Royal', 'R001', 25, 10, 'Available'),
(32, 5, 'Sprite', 'S001', 35, 100, 'Available'),
(33, 6, 'Hotdog', 'P001', 50, 10, 'Available'),
(34, 8, 'Rice', 'R002', 58, 100, 'Available'),
(35, 9, 'Safe Guard', 'SG01', 20, 10, 'Available'),
(36, 9, 'Zonrox', 'Z001', 17, 7, 'Available'),
(37, 9, 'Floor Wax', 'F001', 25, 97, 'Available'),
(38, 8, 'Bulad', 'B001', 10, 10, 'Available'),
(39, 6, 'Ice Cube', 'I001', 12, 91, 'Available'),
(40, 9, 'katol', 'P003', 3, 50, 'Available'),
(41, 9, 'shampoo', 'P002', 6, 50, 'Available'),
(42, 6, 'tocino', 'P006', 40, 40, 'Not Available'),
(43, 5, 'corn beef', 'P008', 20, 40, 'Available');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL,
  `fname` varchar(100) NOT NULL,
  `mname` varchar(100) NOT NULL,
  `lname` varchar(100) NOT NULL,
  `sex` varchar(100) NOT NULL,
  `birthdate` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `fname`, `mname`, `lname`, `sex`, `birthdate`, `email`, `username`, `password`) VALUES
(7, 'Junmer', 'Notarion', 'Banquil', 'Male', '2023-11-26', 'junmerbanquil26@gmail.com', 'jhong', '77f2d9ad929867ced766caed2092d9b8430f985b56d0062d1b1a87fcdc89bd6a'),
(8, 'Junmer', 'Notarion', 'Banquil', 'Female', '2002-12-07', 'kristine@gmail.com', 'jong', '414bcda764694ffe8a34d346a6560e2f87d926782a1244aeb14673b104c74eea'),
(9, 'kenken', 'opeop', 'palen ', 'Female', '2023-12-05', 'ken@gmail.com', 'kenken', '640a731fdef6db5afbf6461c5de839efd354cb3b1b5ad02cfcbd7b08b5ba01a2');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `address`
--
ALTER TABLE `address`
  ADD PRIMARY KEY (`address_id`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`cart_id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`categoryID`);

--
-- Indexes for table `order`
--
ALTER TABLE `order`
  ADD PRIMARY KEY (`orderID`);

--
-- Indexes for table `orderdetails`
--
ALTER TABLE `orderdetails`
  ADD PRIMARY KEY (`orderDetailsID`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`productID`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `address`
--
ALTER TABLE `address`
  MODIFY `address_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `cart_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=82;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `categoryID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `order`
--
ALTER TABLE `order`
  MODIFY `orderID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `orderdetails`
--
ALTER TABLE `orderdetails`
  MODIFY `orderDetailsID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `productID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
