package grocerystore;

import java.util.Date;

public class order {
    private int orderID;
    private String customerName;
    private String totalQuantity;
    private String address;
    private Date date;

    public order(int orderID, String customerName, String totalQuantity, String address, Date date) {
        this.orderID = orderID;
        this.customerName = customerName;
        this.totalQuantity = totalQuantity;
        this.address = address;
        this.date = date;
    }

    public int getOrderID() {
        return orderID;
    }

    public String getCustomerName() {
        return customerName;
    }

    public String getTotalQuantity() {
        return totalQuantity;
    }

    public String getAddress() {
        return address;
    }

    public Date getDate() {
        return date;
    }
}
