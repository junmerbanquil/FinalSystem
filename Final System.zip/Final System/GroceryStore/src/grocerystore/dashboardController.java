/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package grocerystore;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;


import javafx.animation.TranslateTransition;
import javafx.util.Duration;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.SQLException;
import de.jensd.fx.glyphs.fontawesome.FontAwesomeIcon;
import java.io.IOException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DateFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import javafx.collections.transformation.FilteredList;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.collections.transformation.SortedList;
import javafx.application.Platform;
import javafx.scene.chart.AreaChart;
import javafx.scene.control.CheckBox;
/**
 *
 * @author Wayt Turks
 */
public class dashboardController implements Initializable {

    @FXML
    private TableColumn<order, String> order_col_address;

    @FXML
    private TableColumn<order, String> order_col_customerName;

    @FXML
    private TableColumn<order, Date> order_col_date;

    @FXML
    private TableColumn<order, Integer> order_col_orderID;

    @FXML
    private TableColumn<order, Double> order_col_totalQuantity;

    @FXML
    private TableView<order> order_table;
    
    @FXML
    private TableColumn<?, ?> productSales_col_id;

    @FXML
    private TableColumn<?, ?> productSales_col_productName;

    @FXML
    private TableColumn<?, ?> productSales_col_totalSales;

    @FXML
    private TableView<?> productSales_table;

    
    @FXML
    private TableView<OrderDetails> order_details_table;

    @FXML
    private TableColumn<?, ?> order_col_price;

    @FXML
    private TableColumn<?, ?> order_col_productName;

    @FXML
    private TableColumn<?, ?> order_col_quantity;
    
    @FXML
    private BarChart<?, ?> dashboard_productSold;
        
    @FXML
    private LineChart<?, ?> dashboard_NOrderChart;
    
    @FXML
    private Button profileShowBtn;
    
    @FXML
    private Button profileClose;

    @FXML
    private TextField profilePassword;
    
    @FXML
    private TextField orderID_display;

    // MONTH SELECTOR START###########################
    @FXML
    private ComboBox<String> monthSelector;

    // MONTH SELECTOR END  ###########################
    @FXML
    private AnchorPane profileSettingsPanel;

    @FXML
    private CheckBox profileShowPassword;

    @FXML
    private TextField profileUsername;
    
    @FXML
    private TextField category_id;
    
    @FXML
    private TextField getCategoryName;
    
    @FXML
    private AnchorPane navMenu;
    
    @FXML
    private TextField category_code;

    @FXML
    private TextField category_name;

    @FXML
    private Button category_addBtn;
    
    @FXML
    private TableView<category> allCategory_tableView;

    @FXML
    private TableColumn<category, String> category_col_categoryCode;

    @FXML
    private TableColumn<category, String> category_col_categoryID;

    @FXML
    private TableColumn<category, String> category_col_categoryName;
    
    @FXML
    private FontAwesomeIcon close;

    @FXML
    private Button dashboard_btn;

    @FXML
    private AnchorPane dashboard_form;

    @FXML
    private TextField product_id;
    
    @FXML
    private AreaChart<?, ?> dashboard_incomeChart;

    @FXML
    private AnchorPane dashboard_todaysIncome;

    @FXML
    private AnchorPane dashboard_totalIncome;

    @FXML
    private AnchorPane dashboard_totalProducts;

    @FXML
    private FontAwesomeIcon logout_btn;

    @FXML
    private FontAwesomeIcon minimize;

    @FXML
    private Button sales_btn;
    

    @FXML
    private Button prod_addBtn;

    @FXML
    private Button prod_clearBtn;
    
    @FXML
    private Button category_clear;

    @FXML
    private TableColumn<products, String> prod_col_productID;    
    
    @FXML
    private TableColumn<products, String> prod_col_productCategory;

    @FXML
    private TableColumn<products, String> prod_col_productCode;

    @FXML
    private TableColumn<products, String> prod_col_productId;

    @FXML
    private TableColumn<products, String> prod_col_productName;

    @FXML
    private TableColumn<products, String> prod_col_productPrice;
    
    @FXML
    private TableColumn<products, Integer> prod_col_productStock;

    @FXML
    private TableColumn<products, String> prod_col_productStatus;

    @FXML
    private Button prod_deleteBtn;
    
    @FXML
    private Button category_deleteBtn;
    
    @FXML
    private Button category_btn;
    
    @FXML
    private Button orders_btn;

    @FXML
    private AnchorPane category_form;
    
    @FXML
    private AnchorPane orders_form;
    
    @FXML
    private AnchorPane sales_form;
    
    @FXML
    private ComboBox<category> prod_productCategory;

    @FXML
    private TextField prod_productCode;

    @FXML
    private TextField prod_productName;

    @FXML
    private TextField prod_productPrice;
    
    @FXML
    private TextField prod_productStock;

    @FXML
    private ComboBox<?> prod_productStatus;

    @FXML
    private TextField prod_search;
    
    @FXML
    private TextField category_search;
    

    @FXML
    private TableView<products> allProd_tableView;
    
    @FXML
    private Button prod_updateBtn;

    @FXML
    private Button products_btn;

    @FXML
    private AnchorPane main_form;

    @FXML
    private AnchorPane products_form;

    @FXML
    private Label username;
    
    @FXML
    private Label order_details_total;
    
    @FXML
    private Label stat_totalIncome;
    
    @FXML
    private Label stat_todaysIncome;
    
    @FXML
    private Label stat_totalProducts;        
            
    private Connection connect;
    private PreparedStatement prepare;
    private Statement statement;
    private ResultSet result;
    
    
 
    //ADD PRODUCTS ############################################################
public void addProducts() {
    String sqlCheckName = "SELECT product_name FROM product WHERE product_name = ?";
    String sqlCheckCode = "SELECT product_code FROM product WHERE product_code = ?";
    String sqlInsert = "INSERT INTO product (categoryID, product_name, product_code, product_price, product_stock, product_status) VALUES (?,?,?,?,?,?)";
    connect = database.connect();

    try {
        if (prod_productName.getText().isEmpty() || prod_productCode.getText().isEmpty() || prod_productPrice.getText().isEmpty() || prod_productStock.getText().isEmpty() || prod_productStatus.getSelectionModel().isEmpty() || prod_productCategory.getSelectionModel().isEmpty()) {
            Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Error Message");
            alert.setHeaderText(null);
            alert.setContentText("Please fill all fields!");
            alert.showAndWait();
            return; // Exit method if any field is empty or category is not selected
        }

        // Validate stock input
        String stockInput = prod_productStock.getText().trim(); // Trim to remove leading/trailing spaces

        // Check if stockInput contains only numbers
        if (!stockInput.matches("\\d+")) {
            Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Error Message");
            alert.setHeaderText(null);
            alert.setContentText("Invalid stock! Please enter numbers only.");
            alert.showAndWait();
            return; // Exit method if validation fails
        }

        int stockValue = Integer.parseInt(stockInput);

        // Check if stock is less than 1
        if (stockValue < 1) {
            Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Error Message");
            alert.setHeaderText(null);
            alert.setContentText("Stock should not be less than 1.");
            alert.showAndWait();
            return; // Exit method if validation fails
        }

        // Check if product_name already exists
        PreparedStatement checkNameStatement = connect.prepareStatement(sqlCheckName);
            checkNameStatement.setString(1, prod_productName.getText());
            ResultSet nameResult = checkNameStatement.executeQuery();

            if (nameResult.next()) {
                Alert alert = new Alert(AlertType.ERROR);
                alert.setTitle("Error Message");
                alert.setHeaderText(null);
                alert.setContentText("Product Name: " + prod_productName.getText() + " already exists!");
                alert.showAndWait();
                return; // Exit method if the product name already exists
            }

            // Check if product_code already exists
            PreparedStatement checkCodeStatement = connect.prepareStatement(sqlCheckCode);
            checkCodeStatement.setString(1, prod_productCode.getText());
            ResultSet codeResult = checkCodeStatement.executeQuery();

            if (codeResult.next()) {
                Alert alert = new Alert(AlertType.ERROR);
                alert.setTitle("Error Message");
                alert.setHeaderText(null);
                alert.setContentText("Product Code: " + prod_productCode.getText() + " already exists!");
                alert.showAndWait();
                return; // Exit method if the product code already exists
            }

            // If product name and code don't exist and all fields are filled, proceed with insertion
            PreparedStatement insertStatement = connect.prepareStatement(sqlInsert);
            category selectedCategory = prod_productCategory.getSelectionModel().getSelectedItem();
            int categoryId = selectedCategory.getCategoryId(); // Adjust this based on your 'Category' class structure

            insertStatement.setInt(1, categoryId);
            insertStatement.setString(2, prod_productName.getText());
            insertStatement.setString(3, prod_productCode.getText());
            insertStatement.setDouble(4, Double.parseDouble(prod_productPrice.getText()));
            insertStatement.setInt(5, Integer.parseInt(prod_productStock.getText()));
            insertStatement.setString(6, (String) prod_productStatus.getSelectionModel().getSelectedItem());

            insertStatement.executeUpdate();

            Alert alert = new Alert(AlertType.INFORMATION);
            alert.setTitle("Information Message");
            alert.setHeaderText(null);
            alert.setContentText("Successfully Added!");
            alert.showAndWait();

            populateCategoryComboBox();
            allProductShowData();
            allProductClear();

    } catch (SQLException | NumberFormatException e) {
        e.printStackTrace();
    }
}

    //ADD PRODUCTS ############################################################

    
    
    //ADD CATEGORY ############################################################
    public void addCategory() {
    String sqlCheckCode = "SELECT category_code FROM category WHERE category_code = ?";
    String sqlCheckName = "SELECT category_name FROM category WHERE category_name = ?";
    String sqlInsert = "INSERT INTO category (category_code, category_name) VALUES (?,?)";
    connect = database.connect();

    try {
        if (category_code.getText().isEmpty() || category_name.getText().isEmpty()) {
            Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Error Message");
            alert.setHeaderText(null);
            alert.setContentText("Please fill all fields!");
            alert.showAndWait();
            return; // Exit method if any field is empty
        }

        // Check if category code already exists
        PreparedStatement checkCodeStatement = connect.prepareStatement(sqlCheckCode);
        checkCodeStatement.setString(1, category_code.getText());
        ResultSet codeResult = checkCodeStatement.executeQuery();

        if (codeResult.next()) {
            Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Error Message");
            alert.setHeaderText(null);
            alert.setContentText("Category Code: " + category_code.getText() + " already exists!");
            alert.showAndWait();
            return; // Exit method if the category code already exists
        }

        // Check if category name already exists
        PreparedStatement checkNameStatement = connect.prepareStatement(sqlCheckName);
        checkNameStatement.setString(1, category_name.getText());
        ResultSet nameResult = checkNameStatement.executeQuery();

        if (nameResult.next()) {
            Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Error Message");
            alert.setHeaderText(null);
            alert.setContentText("Category Name: " + category_name.getText() + " already exists!");
            alert.showAndWait();
            return; // Exit method if the category name already exists
        }

        // If category code and name don't exist and all fields are filled, proceed with insertion
        PreparedStatement insertStatement = connect.prepareStatement(sqlInsert);
        insertStatement.setString(1, category_code.getText());
        insertStatement.setString(2, category_name.getText());

        insertStatement.executeUpdate();

        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("Information Message");
        alert.setHeaderText(null);
        alert.setContentText("Category Successfully Added!");
        alert.showAndWait();

        allCategoryShowData();
        //clearCategoryFields();
    } catch (SQLException e) {
        e.printStackTrace();
    }
}
    //ADD CATEGORY ############################################################
    
    // UPDATE CATEGORY ############################################################
    // UPDATE CATEGORY ############################################################
    public void updateCategory() {
        String sql = "UPDATE category SET category_name = ?, category_code = ? WHERE categoryID = ?";
        String checkExistingCategory = "SELECT * FROM category WHERE (category_code = ? OR category_name = ?) AND categoryID != ?";
        String insertNewCategory = "INSERT INTO category (category_name, category_code) VALUES (?, ?)";
        connect = database.connect();

        try {
            PreparedStatement checkStatement = connect.prepareStatement(checkExistingCategory);
            PreparedStatement updateStatement = connect.prepareStatement(sql);
            PreparedStatement insertStatement = connect.prepareStatement(insertNewCategory);
            Alert alert;

            if (category_name.getText().isEmpty() || category_code.getText().isEmpty() || category_id.getText().isEmpty()) {
                alert = new Alert(AlertType.ERROR);
                alert.setTitle("Error Message");
                alert.setHeaderText(null);
                alert.setContentText("Please fill all blank fields");
                alert.showAndWait();
            } else {
                checkStatement.setString(1, category_code.getText());
                checkStatement.setString(2, category_name.getText());
                checkStatement.setString(3, category_id.getText()); // Pass current category_id here

                ResultSet existingResult = checkStatement.executeQuery();

                if (!existingResult.next()) {
                    alert = new Alert(AlertType.CONFIRMATION);
                    alert.setTitle("Confirmation Message");
                    alert.setHeaderText(null);
                    alert.setContentText("Are you sure you want to update this category?");
                    Optional<ButtonType> optionalResult = alert.showAndWait();

                    if (optionalResult.isPresent() && optionalResult.get() == ButtonType.OK) {
                        updateStatement.setString(1, category_name.getText());
                        updateStatement.setString(2, category_code.getText());
                        updateStatement.setString(3, category_id.getText());

                        int rowsUpdated = updateStatement.executeUpdate();

                        if (rowsUpdated > 0) {
                            alert = new Alert(AlertType.INFORMATION);
                            alert.setTitle("Information Message");
                            alert.setHeaderText(null);
                            alert.setContentText("Category Updated Successfully!");
                            alert.showAndWait();
                            // Additional logic if needed after update
                            allCategoryShowData();
                        } else {
                            alert = new Alert(AlertType.ERROR);
                            alert.setTitle("Error Message");
                            alert.setHeaderText(null);
                            alert.setContentText("Failed to update category.");
                            alert.showAndWait();
                        }
                    } else {
                        alert = new Alert(AlertType.INFORMATION);
                        alert.setTitle("Information Message");
                        alert.setHeaderText(null);
                        alert.setContentText("Cancelled");
                        alert.showAndWait();
                    }
                } else {
                    alert = new Alert(AlertType.ERROR);
                    alert.setTitle("Error Message");
                    alert.setHeaderText(null);
                    alert.setContentText("Category Code or Name already exists for other categories!");
                    alert.showAndWait();
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                connect.close(); // Close the connection in the finally block
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    // UPDATE CATEGORY ############################################################
    // UPDATE CATEGORY ############################################################
    
    
    
    // UPDATE PRODUCT ############################################################
    // UPDATE PRODUCT ############################################################
public void allProductUpdate() {
    String sql = "UPDATE product SET product_code = ?, product_name = ?, categoryID = ?, product_price = ?, product_stock = ?, product_status = ? WHERE productID = ?";
    String checkExistingProduct = "SELECT * FROM product WHERE (product_code = ? OR product_name = ?) AND productID != ?";
    connect = database.connect();

    try {
        PreparedStatement checkStatement = connect.prepareStatement(checkExistingProduct);
        PreparedStatement preparedStatement = connect.prepareStatement(sql);
        Alert alert;

        if (product_id.getText().isEmpty() ||
            prod_productName.getText().isEmpty() ||
            prod_productCategory.getSelectionModel().isEmpty() ||
            prod_productPrice.getText().isEmpty() ||
            prod_productStock.getText().isEmpty() ||
            prod_productStatus.getSelectionModel().isEmpty()) {

            alert = new Alert(AlertType.ERROR);
            alert.setTitle("Error Message");
            alert.setHeaderText(null);
            alert.setContentText("Please fill all blank fields");
            alert.showAndWait();
        } else {
            checkStatement.setString(1, product_id.getText());
            checkStatement.setString(2, prod_productName.getText());
            checkStatement.setString(3, product_id.getText()); // Pass current product ID here

            ResultSet existingResult = checkStatement.executeQuery();

            if (!existingResult.next()) {
                alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Message");
                alert.setHeaderText(null);
                alert.setContentText("Are you sure you want to Update Product ID:" + product_id.getText() + "?");
                Optional<ButtonType> optionalResult = alert.showAndWait();

                if (optionalResult.isPresent() && optionalResult.get() == ButtonType.OK) {
                    // Validate stock input
                    String stockInput = prod_productStock.getText().trim(); // Trim to remove leading/trailing spaces

                    // Check if stockInput contains only numbers
                    if (!stockInput.matches("\\d+")) {
                        alert = new Alert(AlertType.ERROR);
                        alert.setTitle("Error Message");
                        alert.setHeaderText(null);
                        alert.setContentText("Invalid stock! Please enter numbers only.");
                        alert.showAndWait();
                        return; // Exit method if validation fails
                    }

                    int stockValue = Integer.parseInt(stockInput);

                    // Check if stock is less than 1
                    if (stockValue < 1) {
                        alert = new Alert(AlertType.ERROR);
                        alert.setTitle("Error Message");
                        alert.setHeaderText(null);
                        alert.setContentText("Stock should not be less than 1.");
                        alert.showAndWait();
                        return; // Exit method if validation fails
                    }

                    category selectedCategory = prod_productCategory.getSelectionModel().getSelectedItem();
                    int categoryId = selectedCategory.getCategoryId();

                    preparedStatement.setString(1, prod_productCode.getText());
                    preparedStatement.setString(2, prod_productName.getText());
                    preparedStatement.setInt(3, categoryId);
                    preparedStatement.setDouble(4, Double.parseDouble(prod_productPrice.getText()));
                    preparedStatement.setInt(5, stockValue);
                    preparedStatement.setString(6, (String) prod_productStatus.getSelectionModel().getSelectedItem());
                    preparedStatement.setString(7, product_id.getText());

                    int rowsUpdated = preparedStatement.executeUpdate();
                    if (rowsUpdated > 0) {
                        alert = new Alert(AlertType.INFORMATION);
                        alert.setTitle("Information Message");
                        alert.setHeaderText(null);
                        alert.setContentText("Successfully Updated!");
                        alert.showAndWait();

                        populateCategoryComboBox();
                        allProductShowData();
                        allProductClear();
                    } else {
                        alert = new Alert(AlertType.ERROR);
                        alert.setTitle("Error Message");
                        alert.setHeaderText(null);
                        alert.setContentText("Something went wrong");
                        alert.showAndWait();
                    }
                } else {
                    alert = new Alert(AlertType.INFORMATION);
                    alert.setTitle("Information Message");
                    alert.setHeaderText(null);
                    alert.setContentText("Cancelled");
                    alert.showAndWait();
                }
            } else {
                alert = new Alert(AlertType.ERROR);
                alert.setTitle("Error Message");
                alert.setHeaderText(null);
                alert.setContentText("Product Code or Name already exists for other products!");
                alert.showAndWait();
            }
        }
    } catch (SQLException | NumberFormatException e) {
        e.printStackTrace();
    } finally {
        try {
            connect.close(); // Close the connection in the finally block
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
    // UPDATE PRODUCT ############################################################
    // UPDATE PRODUCT ############################################################



    // DELETE PRODUCT ############################################################
    // DELETE PRODUCT ############################################################
    public void allProductDelete(){
    String sql = "DELETE FROM product WHERE product_code = '" +prod_productCode.getText()+"'";

    connect = database.connect();

    try{
    Alert alert;

    if (prod_productCode.getText().isEmpty() &&
                prod_productName.getText().isEmpty() &&
                prod_productCategory.getSelectionModel().getSelectedItem() == null ||
                prod_productPrice.getText().isEmpty() &&
                prod_productStatus.getSelectionModel().getSelectedItem() == null){

                alert = new Alert(AlertType.ERROR);
                alert.setTitle("Error Message");
                alert.setHeaderText(null);
                alert.setContentText("Please fill all blank fields");
                alert.showAndWait();
            }else{

                alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Message");
                alert.setHeaderText(null);
                alert.setContentText("Are you sure you want to Delete Product Code:" + prod_productCode.getText() + "?");
                Optional<ButtonType> option = alert.showAndWait();

                if(option.get().equals(ButtonType.OK)){

                    alert = new Alert(AlertType.INFORMATION);
                    alert.setTitle("Information Message");
                    alert.setHeaderText(null);
                    alert.setContentText("Successfully Deleted!");
                    alert.showAndWait();

                    statement = connect.createStatement();
                    statement.executeUpdate(sql);

                    populateCategoryComboBox();
                    //show data on table
                    allProductShowData();
                    //clear text field
                    allProductClear();


                }else{

                    alert = new Alert(AlertType.INFORMATION);
                    alert.setTitle("Information Message");
                    alert.setHeaderText(null);
                    alert.setContentText("Cancelled");
                    alert.showAndWait();
                }
            }
        }catch(Exception e){e.printStackTrace();
    }}
    // DELETE PRODUCT ############################################################
    // DELETE PRODUCT ############################################################
    
    
    
    // DELETE CATEGORY ############################################################
    // DELETE CATEGORY ############################################################
    public void allCategoryDelete() {
    String sql = "DELETE FROM category WHERE category_code = ?";
    String checkProductsUsingCategory = "SELECT * FROM product WHERE categoryID = ?";
    connect = database.connect();

    try {
        PreparedStatement deleteStatement = connect.prepareStatement(sql);
        PreparedStatement checkProductsStatement = connect.prepareStatement(checkProductsUsingCategory);
        Alert alert;

        if (category_code.getText().isEmpty() || category_name.getText().isEmpty() || category_id.getText().isEmpty()) {
            alert = new Alert(AlertType.ERROR);
            alert.setTitle("Error Message");
            alert.setHeaderText(null);
            alert.setContentText("Please fill all blank fields");
            alert.showAndWait();
        } else {
            checkProductsStatement.setInt(1, Integer.parseInt(category_id.getText()));
            ResultSet productsUsingCategory = checkProductsStatement.executeQuery();

            if (!productsUsingCategory.next()) {
                alert = new Alert(AlertType.CONFIRMATION);
                alert.setTitle("Confirmation Message");
                alert.setHeaderText(null);
                alert.setContentText("Are you sure you want to Delete Category Code:" + category_code.getText() + "?");
                Optional<ButtonType> option = alert.showAndWait();

                if (option.get().equals(ButtonType.OK)) {
                    deleteStatement.setString(1, category_code.getText());
                    deleteStatement.executeUpdate();

                    alert = new Alert(AlertType.INFORMATION);
                    alert.setTitle("Information Message");
                    alert.setHeaderText(null);
                    alert.setContentText("Successfully Deleted!");
                    alert.showAndWait();
                    
                    allCategoryShowData();
                    // Additional logic if needed after deletion

                } else {
                    alert = new Alert(AlertType.INFORMATION);
                    alert.setTitle("Information Message");
                    alert.setHeaderText(null);
                    alert.setContentText("Cancelled");
                    alert.showAndWait();
                }
            } else {
                alert = new Alert(AlertType.ERROR);
                alert.setTitle("Error Message");
                alert.setHeaderText(null);
                alert.setContentText("Category is used by one or more products!");
                alert.showAndWait();
            }
        }
    } catch (SQLException | NumberFormatException e) {
        e.printStackTrace();
    } finally {
        try {
            connect.close(); // Close the connection in the finally block
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
    // DELETE CATEGORY ############################################################
    // DELETE CATEGORY ############################################################

    
    
    // CLEAR PRODUCT TEXT FIELDS ############################################################
    // CLEAR PRODUCT TEXT FIELDS ############################################################
    public void allProductClear(){
        prod_productCode.setText("");
        product_id.setText("");
        prod_productName.setText("");
        prod_productPrice.setText("");
        prod_productStock.setText("");
        prod_productCategory.getSelectionModel().clearSelection();
        prod_productStatus.getSelectionModel().clearSelection();
        prod_productCode.setEditable(true);
        prod_productCategory.setDisable(false);
    }
    // CLEAR PRODUCT TEXT FIELDS ############################################################
    // CLEAR PRODUCT TEXT FIELDS ############################################################
    
    
    
    // CLEAR PRODUCT TEXT FIELDS ############################################################
    // CLEAR PRODUCT TEXT FIELDS ############################################################
    public void allCategoryClear(){
        category_code.setText("");
        category_name.setText("");
        category_id.setText("");
    }
    // CLEAR PRODUCT TEXT FIELDS ############################################################
    // CLEAR PRODUCT TEXT FIELDS ############################################################
    
    

    //DATA TABLE CATEGORY ########################################################
    //DATA TABLE CATEGORY ########################################################
    private ObservableList<category> allCategoryListData(){
    ObservableList<category> listData = FXCollections.observableArrayList();

    String sql = "SELECT * FROM category";

    connect = (Connection) database.connect();

    try{

    prepare = connect.prepareStatement(sql);
    result = prepare.executeQuery();

    category cat;

    while(result.next()){
    cat = new category(result.getInt("categoryID"), result.getString("category_code"), result.getString("category_name"));
    listData.add(cat);
    }

    }catch(Exception e){e.printStackTrace();
    }
    return listData;
    }
    
    
FilteredList<category> allCategoryList = new FilteredList<>(allCategoryListData(), e -> true);
public void allCategoryShowData(){
    // Initialize sortedList as a SortedList that wraps allCategoryList
    SortedList<category> sortedList = new SortedList<>(allCategoryList);

    // Set up the columns
    category_col_categoryID.setCellValueFactory(new PropertyValueFactory<>("categoryId"));
    category_col_categoryCode.setCellValueFactory(new PropertyValueFactory<>("name"));
    category_col_categoryName.setCellValueFactory(new PropertyValueFactory<>("code"));

    // Set the items to sortedList instead of allCategoryList
    allCategory_tableView.setItems(sortedList);
    sortedList.comparatorProperty().bind(allCategory_tableView.comparatorProperty());
}
    //DATA TABLE CATEGORY ########################################################
    //DATA TABLE CATEGORY ########################################################



    //PRODUCT DATA TABLE ########################################################
    //PRODUCT DATA TABLE ########################################################
    private ObservableList<products> allProductListData(){
    ObservableList<products> listData = FXCollections.observableArrayList();

    String sql = "SELECT p.productID, p.product_name, p.product_code, p.product_price, p.product_stock, p.product_status, c.category_name " +
            "FROM product p " +
            "JOIN category c ON p.categoryID = c.categoryID";

    connect = (Connection) database.connect();

    try{

    prepare = connect.prepareStatement(sql);
    result = prepare.executeQuery();

    products cat;

    while(result.next()){
    cat = new products(result.getInt("productID"), result.getString("category_name"), result.getString("product_name"), result.getString("product_code"), result.getDouble("product_price"), result.getInt("product_stock"), result.getString("product_status"));
    listData.add(cat);
    }

    }catch(Exception e){e.printStackTrace();
    }
    return listData;
    }
    
    FilteredList<products> allProductList;
    public void allProductShowData(){
    // Initialize allProductList as a FilteredList
    allProductList = new FilteredList<>(allProductListData(), e -> true);

    // Initialize sortedList as a SortedList that wraps allProductList
    SortedList<products> sortedList = new SortedList<>(allProductList);

    // Set up the columns
    prod_col_productID.setCellValueFactory(new PropertyValueFactory<>("productId"));
    prod_col_productCode.setCellValueFactory(new PropertyValueFactory<>("code"));
    prod_col_productName.setCellValueFactory(new PropertyValueFactory<>("name"));
    prod_col_productPrice.setCellValueFactory(new PropertyValueFactory<>("price"));
    prod_col_productStock.setCellValueFactory(new PropertyValueFactory<>("stock"));
    prod_col_productCategory.setCellValueFactory(new PropertyValueFactory<>("categoryName")); 
    prod_col_productStatus.setCellValueFactory(new PropertyValueFactory<>("status"));

    // Set the items to sortedList instead of allProductList
    allProd_tableView.setItems(sortedList);
    sortedList.comparatorProperty().bind(allProd_tableView.comparatorProperty());
    }
    //PRODUCT DATA TABLE ########################################################
    //PRODUCT DATA TABLE ########################################################

    
    
    //ORDERS DATA TABLE ########################################################
    //ORDERS DATA TABLE ########################################################
    private ObservableList<order> allOrderListData(){
        ObservableList<order> listData = FXCollections.observableArrayList();
        
        String sql = "SELECT o.orderID, u.fname, u.lname, o.total_quantity, o.address, o.date " +
                "FROM `order` o " +
                "JOIN user u ON o.user_id = u.user_id";

        connect = (Connection) database.connect();

        try{
            prepare = connect.prepareStatement(sql);
            result = prepare.executeQuery();

            while(result.next()){
                
                int orderId = result.getInt("orderID");
                String customerName = result.getString("fname") + " " + result.getString("lname");
                String grandTotalQuantity = result.getString("total_quantity");
                String address = result.getString("address");
                Date date = result.getDate("date");

                order order = new order(orderId, customerName, grandTotalQuantity, address, date);
                listData.add(order);
            }
        } catch(Exception e){
            e.printStackTrace();
        }
        return listData;
    }

    FilteredList<order> allOrderList;

    public void allOrderShowData(){
        allOrderList = new FilteredList<>(allOrderListData(), e -> true);
        SortedList<order> sortedList = new SortedList<>(allOrderList);
        
        order_col_orderID.setCellValueFactory(new PropertyValueFactory<>("orderID"));
        order_col_customerName.setCellValueFactory(new PropertyValueFactory<>("customerName"));
        order_col_totalQuantity.setCellValueFactory(new PropertyValueFactory<>("totalQuantity"));
        order_col_address.setCellValueFactory(new PropertyValueFactory<>("address"));
        order_col_date.setCellValueFactory(new PropertyValueFactory<>("date"));

        order_table.setItems(sortedList);
        sortedList.comparatorProperty().bind(order_table.comparatorProperty());
    }

    //ORDERS DATA TABLE ########################################################
    //ORDERS DATA TABLE ########################################################
    
    //ORDERS DATA SELECT ########################################################
    //ORDERS DATA SELECT ########################################################
    public void allOrderSelect() {
        order selectedOrder = order_table.getSelectionModel().getSelectedItem();

        if (selectedOrder == null) {
            return; // No selection, do nothing
        }

        orderID_display.setText(String.valueOf(selectedOrder.getOrderID()));
        allOrderDetailsShowData();
    }

    //ORDERS DATA SELECT ########################################################
    //ORDERS DATA SELECT ########################################################
    
    
    
    //MONTH SELECTOR #######################################################

    //MONTH SELECTOR #######################################################
    
        
    //ORDER DETAILS TABLE VIEW ########################################################
    //ORDER DETAILS TABLE VIEW ########################################################
    private ObservableList<OrderDetails> allOrderDetailsListData(){
        ObservableList<OrderDetails> listData = FXCollections.observableArrayList();

        String sql = "SELECT orderdetails.orderID, product.product_name, orderdetails.quantity, orderdetails.total_price " +
                     "FROM orderdetails " +
                     "INNER JOIN product ON orderdetails.productID = product.productID " +
                     "WHERE orderdetails.orderID = ?";

        connect = (Connection) database.connect();

        try{
            prepare = connect.prepareStatement(sql);
            prepare.setString(1, orderID_display.getText());
            result = prepare.executeQuery();

            while(result.next()){

                int orderId = result.getInt("orderID");
                String productName = result.getString("product_name");
                String quantity = result.getString("quantity");
                Double totalPrice = result.getDouble("total_price");

                OrderDetails orderDetails = new OrderDetails(orderId, productName, quantity, totalPrice);
                listData.add(orderDetails);
            }
        } catch(Exception e){
            e.printStackTrace();
        }
        return listData;
    }

    FilteredList<OrderDetails> allOrderDetailsList;

    public void allOrderDetailsShowData(){
        allOrderDetailsList = new FilteredList<>(allOrderDetailsListData(), e -> true);
        SortedList<OrderDetails> sortedList = new SortedList<>(allOrderDetailsList);

        order_col_orderID.setCellValueFactory(new PropertyValueFactory<>("orderID"));
        order_col_productName.setCellValueFactory(new PropertyValueFactory<>("productName"));
        order_col_quantity.setCellValueFactory(new PropertyValueFactory<>("quantity"));
        order_col_price.setCellValueFactory(new PropertyValueFactory<>("totalPrice"));

        order_details_table.setItems(sortedList);
        sortedList.comparatorProperty().bind(order_details_table.comparatorProperty());
        // Calculate the total price
        double totalPrice = allOrderDetailsList.stream().mapToDouble(OrderDetails::getTotalPrice).sum();
        order_details_total.setText(String.valueOf(totalPrice));
    }


    //ORDER DETAILS TABLE VIEW ########################################################
    //ORDER DETAILS TABLE VIEW ########################################################
    
    
    
    //PRODUCT SALES TABLE VIEW ########################################################
    //PRODUCT SALES TABLE VIEW ########################################################
    private ObservableList<OrderDetails> productSalesListData(){
        ObservableList<OrderDetails> listData = FXCollections.observableArrayList();

        String sql = "SELECT product.productID, product.product_name, SUM(orderdetails.total_price) as total_sales " +
                     "FROM orderdetails " +
                     "INNER JOIN product ON orderdetails.productID = product.productID " +
                     "GROUP BY product.productID";

        connect = (Connection) database.connect();

        try{
            prepare = connect.prepareStatement(sql);
            result = prepare.executeQuery();

            while(result.next()){
                int productId = result.getInt("productID");
                String productName = result.getString("product_name");
                Double totalSales = result.getDouble("total_sales");

                OrderDetails productSales = new OrderDetails(productId, productName, totalSales);
                listData.add(productSales);
            }
        } catch(Exception e){
            e.printStackTrace();
        }
        return listData;
    }

    FilteredList<OrderDetails> productSalesList;

    public void productSalesShowData(){
        productSalesList = new FilteredList<>(productSalesListData(), e -> true);
        SortedList<OrderDetails> sortedList = new SortedList<>(productSalesList);

        ((TableColumn<OrderDetails, Integer>) productSales_col_id).setCellValueFactory(new PropertyValueFactory<>("productId"));
        ((TableColumn<OrderDetails, String>) productSales_col_productName).setCellValueFactory(new PropertyValueFactory<>("productName"));
        ((TableColumn<OrderDetails, Double>) productSales_col_totalSales).setCellValueFactory(new PropertyValueFactory<>("totalSales"));

        ObservableList<OrderDetails> observableList = FXCollections.observableArrayList(sortedList);
        ((TableView<OrderDetails>) productSales_table).setItems(observableList);
    }


    //PRODUCT SALES TABLE VIEW ########################################################
    //PRODUCT SALES TABLE VIEW ########################################################
    
    
    
    //SEARCH ########################################################
    //SEARCH ########################################################
public void allProductSearch() {
    prod_search.textProperty().addListener((observable, oldValue, newValue) -> {
        allProductList.setPredicate(product -> {
            if (newValue == null || newValue.isEmpty()) {
                return true;
            }

            String searchKey = newValue.toLowerCase();

            return String.valueOf(product.getProductId()).toLowerCase().contains(searchKey) ||
                   product.getCode().toLowerCase().contains(searchKey) ||
                   product.getName().toLowerCase().contains(searchKey) ||
                   String.valueOf(product.getPrice()).toLowerCase().contains(searchKey) ||
                   String.valueOf(product.getStock()).toLowerCase().contains(searchKey) ||
                   product.getCategoryName().toLowerCase().contains(searchKey) ||
                   product.getStatus().toLowerCase().contains(searchKey);
                   
        });
    });
}

public void allCategorySearch() {
    category_search.textProperty().addListener((observable, oldValue, newValue) -> {
        allCategoryList.setPredicate(category -> {  
            if (newValue == null || newValue.isEmpty()) {
                return true;
            }

            String searchKey = newValue.toLowerCase();

            return String.valueOf(category.getCategoryId()).toLowerCase().contains(searchKey) ||
                   category.getCode().toLowerCase().contains(searchKey) ||
                   category.getName().toLowerCase().contains(searchKey);
                   
        });
    });
}


    //SEARCH ########################################################
    //SEARCH ########################################################


    //VIEW products TABLE DETAILS INTO TEXT FIELD ########################################################
    //VIEW productsTABLE DETAILS INTO TEXT FIELD ########################################################
    public void allProductSelect(){

        products catData = allProd_tableView.getSelectionModel().getSelectedItem();
        int num = allProd_tableView.getSelectionModel().getSelectedIndex();

        if((num -1) < -1){
        return;
        }
        
        product_id.setText(String.valueOf(catData.getProductId()));
        prod_productCode.setText(catData.getCode());
        prod_productName.setText(catData.getName());	
        prod_productPrice.setText(String.valueOf(catData.getPrice()));	
        prod_productStock.setText(String.valueOf(catData.getStock()));	
        getCategoryName.setText(String.valueOf(catData.getCategoryName()));	
        prod_productCategory.setDisable(true);
        prod_productStock.setDisable(true);
        
        
        // Get the status of the selected product
        String selectedStatus = catData.getStatus();

        // Loop through ComboBox items to find the matching status and select it
        ObservableList<?> items = prod_productStatus.getItems();
        for (Object item : items) {
            String status = (String) item; // Assuming ComboBox holds strings
            if (status.equals(selectedStatus)) {
                // Find the index of the item to select
                int index = prod_productStatus.getItems().indexOf(item);
                prod_productStatus.getSelectionModel().select(index);
                break;
            }
        }
        
        String selectedCategory = getCategoryName.getText(); // Get the category name from the TextField
ObservableList<?> itemss = prod_productCategory.getItems();

for (Object item : itemss) {
    if (item.toString().equals(selectedCategory)) { // Compare item.toString() with selectedCategory
        int index = itemss.indexOf(item);
        prod_productCategory.getSelectionModel().select(index);
        break;
    }
}


        
        
    }
    //VIEW products TABLE DETAILS INTO TEXT FIELD ########################################################
    //VIEW products TABLE DETAILS INTO TEXT FIELD ########################################################

        //VIEW CATEGORY TABLE DETAILS INTO TEXT FIELD ########################################################
        public void allCategorySelect() {
            category catData = allCategory_tableView.getSelectionModel().getSelectedItem();
            int num = allCategory_tableView.getSelectionModel().getSelectedIndex();

            if ((num - 1) < -1) {
                return;
            }

            category_id.setText(String.valueOf(catData.getCategoryId()));
            category_code.setText(catData.getName());
            category_name.setText(catData.getCode());
                
        }

        //VIEW CATEGORY TABLE DETAILS INTO TEXT FIELD ########################################################

        //ADD CATEGORY TO COMBO BOX ########################################################
        private ObservableList<category> getAllCategories() {
        ObservableList<category> catList = FXCollections.observableArrayList();

        String sql = "SELECT categoryID, category_name, category_code FROM category";
        connect = database.connect();
        try {
            prepare = connect.prepareStatement(sql);
            result = prepare.executeQuery();

            while (result.next()) {
                int categoryId = result.getInt("categoryID");
                String categoryName = result.getString("category_name");
                String categoryCode = result.getString("category_code");

                category cat = new category(categoryId, categoryName, categoryCode);
                catList.add(cat);
            }

            // Close resources after usage
            result.close();
            prepare.close();
            connect.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return catList;
    }

        private ObservableList<category> allCategories;

        public void populateCategoryComboBox() {
            allCategories = getAllCategories();
            prod_productCategory.setItems(allCategories); // Set items to the ComboBox
        }
        //ADD CATEGORY TO COMBO BOX ########################################################



        private final String[] status = {"Available", "Not Available"};
        public void allProductStatus(){
            List<String> listStatus = new ArrayList<>();

            for(String data: status){
                    listStatus.add(data);
            }

            ObservableList listData = FXCollections.observableArrayList(listStatus);
            prod_productStatus.setItems(listData);
        }

        

        public void switchForm(ActionEvent event){
        if(event.getSource() == dashboard_btn){
            dashboard_form.setVisible(true);
            products_form.setVisible(false);
            category_form.setVisible(false);
            sales_form.setVisible(false);
            orders_form.setVisible(false);

            dashboard_btn.setStyle("-fx-background-color: #006664; -fx-text-fill: #fff; -fx-border-width: 0px;");
            products_btn.setStyle("-fx-background-color: transparent; -fx-border-width: 1px; -fx-text-fill: #000;");
            category_btn.setStyle("-fx-background-color: transparent; -fx-border-width: 1px; -fx-text-fill: #000;");
            orders_btn.setStyle("-fx-background-color: transparent; -fx-border-width: 1px; -fx-text-fill: #000;");
            sales_btn.setStyle("-fx-background-color: transparent; -fx-border-width: 1px; -fx-text-fill: #000;");
            dashboardIncomeChart();
            dashboardCustomerChart();
            updateTotalProductsCount();
            updateTodaysIncome();
            updateTotalIncome();

        }else if(event.getSource() == products_btn){
            dashboard_form.setVisible(false);
            products_form.setVisible(true);
            category_form.setVisible(false);
            sales_form.setVisible(false);
            orders_form.setVisible(false);

            products_btn.setStyle("-fx-background-color: #006664; -fx-text-fill: #fff; -fx-border-width: 0px;");
            category_btn.setStyle("-fx-background-color: transparent; -fx-border-width: 1px; -fx-text-fill: #000;");
            dashboard_btn.setStyle("-fx-background-color: transparent; -fx-border-width: 1px; -fx-text-fill: #000;");
            orders_btn.setStyle("-fx-background-color: transparent; -fx-border-width: 1px; -fx-text-fill: #000;");
            sales_btn.setStyle("-fx-background-color: transparent; -fx-border-width: 1px; -fx-text-fill: #000;");
                
            populateCategoryComboBox();
            allProductShowData();
            allProductSearch();
        }else if(event.getSource() == category_btn){
            dashboard_form.setVisible(false);
            products_form.setVisible(false);
            category_form.setVisible(true);
            sales_form.setVisible(false);
            orders_form.setVisible(false);


            category_btn.setStyle("-fx-background-color: #006664; -fx-text-fill: #fff; -fx-border-width: 0px;");
            products_btn.setStyle("-fx-background-color: transparent; -fx-border-width: 1px; -fx-text-fill: #000;");
            dashboard_btn.setStyle("-fx-background-color: transparent; -fx-border-width: 1px; -fx-text-fill: #000;");
            orders_btn.setStyle("-fx-background-color: transparent; -fx-border-width: 1px; -fx-text-fill: #000;");
            sales_btn.setStyle("-fx-background-color: transparent; -fx-border-width: 1px; -fx-text-fill: #000;");

            allProductShowData();
            populateCategoryComboBox();
            allProductSearch();
        }else if(event.getSource() == orders_btn){
            dashboard_form.setVisible(false);
            products_form.setVisible(false);
            category_form.setVisible(false);
            sales_form.setVisible(false);
            orders_form.setVisible(true);

            orders_btn.setStyle("-fx-background-color: #006664; -fx-text-fill: #fff; -fx-border-width: 0px;");
            dashboard_btn.setStyle("-fx-background-color: transparent; -fx-border-width: 1px; -fx-text-fill: #000;");
            products_btn.setStyle("-fx-background-color: transparent; -fx-border-width: 1px; -fx-text-fill: #000;");
            category_btn.setStyle("-fx-background-color: transparent; -fx-border-width: 1px; -fx-text-fill: #000;");
            sales_btn.setStyle("-fx-background-color: transparent; -fx-border-width: 1px; -fx-text-fill: #000;");

            allProductShowData();
            allOrderShowData();
            populateCategoryComboBox();
            allProductSearch();
        }else if(event.getSource() == sales_btn){
            dashboard_form.setVisible(false);
            products_form.setVisible(false);
            category_form.setVisible(false);
            sales_form.setVisible(true);
            orders_form.setVisible(false);

            sales_btn.setStyle("-fx-background-color: #006664; -fx-text-fill: #fff; -fx-border-width: 0px;");
            dashboard_btn.setStyle("-fx-background-color: transparent; -fx-border-width: 1px; -fx-text-fill: #000;");
            products_btn.setStyle("-fx-background-color: transparent; -fx-border-width: 1px; -fx-text-fill: #000;");
            category_btn.setStyle("-fx-background-color: transparent; -fx-border-width: 1px; -fx-text-fill: #000;");
            orders_btn.setStyle("-fx-background-color: transparent; -fx-border-width: 1px; -fx-text-fill: #000;");
            productSalesShowData();
        }
        }

        private double x = 0;
        private double y = 0;

        public void logout() {
            try {
                Alert alert = new Alert(AlertType.INFORMATION);
                alert.setTitle("Information Message");
                alert.setHeaderText(null);
                alert.setContentText("Are you sure you want to logout?");
                Optional<ButtonType> option = alert.showAndWait();

                if (option.isPresent() && option.get().equals(ButtonType.OK)) {

                    logout_btn.getScene().getWindow().hide();

                    Parent root = FXMLLoader.load(getClass().getResource("FXMLDocument.fxml"));
                    Stage stage = new Stage();
                    Scene scene = new Scene(root);

                    stage.initStyle(StageStyle.TRANSPARENT);

                    root.setOnMousePressed((MouseEvent event) -> {
                        x = event.getSceneX();
                        y = event.getSceneY();
                    });

                    root.setOnMouseDragged((MouseEvent event) -> {
                        stage.setX(event.getScreenX() - x);
                        stage.setY(event.getScreenY() - y);

                        stage.setOpacity(.8f);
                    });

                    root.setOnMouseReleased((MouseEvent event) -> {
                        stage.setOpacity(1);
                    });

                    stage.setScene(scene);
                    stage.show();
                }

            } catch (IOException e) {
            }
        }

        public void displayUsername() {
            String user = data.username;
            user = user.substring(0, 1).toUpperCase() + user.substring(1);
            username.setText(user);
        }

        public void close() {
            System.exit(0);
        }

        public void minimize() {
            Stage stage = (Stage) main_form.getScene().getWindow();
            stage.setIconified(true);
        }

        
        
        //DASHBOARD STATISTIC START #######################################################################################################
        //DASHBOARD STATISTIC START #######################################################################################################
        //DASHBOARD STATISTIC START #######################################################################################################
        public void updateTotalProductsCount() {
            try {
                String query = "SELECT COUNT(*) AS total FROM product";
                connect = (Connection) database.connect();
                prepare = connect.prepareStatement(query);
                ResultSet rs = prepare.executeQuery();

                if (rs.next()) {
                    int totalProducts = rs.getInt("total");
                    stat_totalProducts.setText(Integer.toString(totalProducts));
                }
                prepare.close();
                connect.close();
            } catch (SQLException e) {
                e.printStackTrace();
                System.out.println("SQL Error: " + e.getMessage());
            }

        }
        
                
        public void updateTodaysIncome() {
            try {
                // Get today's date
                SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
                Date date = new Date(System.currentTimeMillis());
                String todayDate = formatter.format(date);

                // Query to calculate today's income
                String query = "SELECT SUM(grand_total) AS todaysIncome FROM `order` WHERE status = 'completed' AND date = ?";
                connect = (Connection) database.connect();
                prepare = connect.prepareStatement(query);
                prepare.setString(1, todayDate);
                ResultSet rs = prepare.executeQuery();

                if (rs.next()) {
                    double todaysIncome = rs.getDouble("todaysIncome");
                    stat_todaysIncome.setText(Double.toString(todaysIncome));
                }

                prepare.close();
                connect.close();
            } catch (SQLException e) {
                e.printStackTrace();
                // Handle SQLException
            }
        }
        
        
        public void updateTotalIncome() {
            try {
                // Query to calculate overall income
                String query = "SELECT SUM(grand_total) AS totalIncome FROM `order` WHERE status = 'completed'";
                connect = (Connection) database.connect();
                prepare = connect.prepareStatement(query);
                ResultSet rs = prepare.executeQuery();

                if (rs.next()) {
                    double totalIncome = rs.getDouble("totalIncome");
                    stat_totalIncome.setText(Double.toString(totalIncome));
                }

                prepare.close();
                connect.close();
            } catch (SQLException e) {
                e.printStackTrace();
                // Handle SQLException
            }
        }

        
        public void dashboardIncomeChart() {
            dashboard_incomeChart.getData().clear();

            String sql = "SELECT date, SUM(grand_total) FROM `order` GROUP BY date ORDER BY TIMESTAMP(date)";
            connect = database.connect();
            XYChart.Series chart = new XYChart.Series();
            try {
                prepare = connect.prepareStatement(sql);
                result = prepare.executeQuery();

                while (result.next()) {
                    chart.getData().add(new XYChart.Data<>(result.getString(1), result.getFloat(2)));
                }

                dashboard_incomeChart.getData().add(chart);

            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        
        public void dashboardCustomerChart(){
            dashboard_productSold.getData().clear();

            String sql = "SELECT o.date, COUNT(od.productID) " +
                         "FROM orderdetails od " +
                         "JOIN `order` o ON od.orderID = o.orderID " +
                         "GROUP BY o.date " +
                         "ORDER BY TIMESTAMP(o.date)";

            connect = database.connect();
            XYChart.Series chart = new XYChart.Series();
            try {
                prepare = connect.prepareStatement(sql);
                result = prepare.executeQuery();

                while (result.next()) {
                    chart.getData().add(new XYChart.Data<>(result.getString(1), result.getInt(2)));
                }

                dashboard_productSold.getData().add(chart);

            } catch (Exception e) {
                e.printStackTrace();
            }
        }


        //DASHBOARD STATISTIC END #########################################################################################################
        //DASHBOARD STATISTIC END #########################################################################################################
        //DASHBOARD STATISTIC END #########################################################################################################
        
        
        
        
        
        
        
        
        @Override
        public void initialize(URL url, ResourceBundle rb) {
            // all statistic
            
            updateTotalProductsCount();
            updateTodaysIncome();
            updateTotalIncome();
            dashboardIncomeChart();
            dashboardCustomerChart();
            
                        
            // load data, initialize UI components, etc
            displayUsername();
            allProductStatus();
            allOrderShowData();
            allProductShowData();
            productSalesShowData();
            allProductSearch();
            
            allCategoryShowData();
            
           //Add the ComboBox initialization from the other code snippet
            populateCategoryComboBox();
            }
    }
