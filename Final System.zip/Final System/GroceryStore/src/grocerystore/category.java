/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package grocerystore;

import javafx.collections.ObservableList;


public class category {
    
    private int categoryId;
    private String name;
    private String code;

    public category(int categoryId, String name, String code){
        this.categoryId = categoryId;
        this.name = name;
        this.code = code;
    }

    public int getCategoryId(){
        return categoryId;
    }
    
    public String getName(){
        return name;
    }
    
    public String getCode(){
        return code;
    }

    @Override
    public String toString() {
        return name; // Display the category name in the combo box
    }

    ObservableList<category> getCategoryName() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
